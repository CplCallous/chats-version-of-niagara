# Niagara-style Android Launcher (clean-room implementation)

A native Kotlin Android home launcher inspired by the user-provided screen recording. It is a fresh project and does not contain Niagara Launcher proprietary source or assets.

## Implemented in this build
- Android Home app intent, app discovery and app launching
- Alphabetical app list with A–Z quick navigation and app search
- Long-press app actions: favorites, Android app info, usage access, uninstall, edit display label, hide/unhide
- Persistent favorites, hidden-app list and app display-label preferences
- Settings sections matching the recording: Productivity, Themes, Advanced
- Productivity preference switches, hidden apps management, usage access shortcut
- Theme editor preview, persistent accent-color palette, saved theme screen, and a custom launcher wallpaper chosen from image files
- Global appearance options including status/navigation UI, labels, alphabet visibility and clock format; the alphabet toggle now changes the home UI
- Eight clock styles with live home-screen rendering, including large, compact, stacked, date/time, bold and hidden clock modes
- Nine basic icon presentation styles, with the chosen style applied to app rows
- JSON backup export/import through Android document picker, reset preferences, system/default-home settings shortcuts
- Calendar agenda preview that requests Android calendar permission and displays up to three upcoming events within the next 14 days
- Optional battery percentage indicator on the home screen
- Usage-based app ordering using Android Usage Access, ranking apps by foreground time across the previous seven days when access is granted
- GitHub Actions workflow to build, align, sign and verify an installable APK artifact

## Build locally
Requires JDK 17, Android SDK platform 35/build-tools 35.0.0 and Gradle 8.9:

```bash
gradle --no-daemon assembleRelease
```

The unsigned output is `app/build/outputs/apk/release/app-release-unsigned.apk`. GitHub Actions signs a CI artifact using an ephemeral key. That signing key is regenerated each build, so builds will not update each other seamlessly; use a persistent private signing key for a production release.

## Important limitations
This is an initial functional clean-room implementation, not a claim of a pixel-perfect or feature-for-feature proprietary Niagara clone. Productivity controls that need privileged notification access, weather providers, a widget host, media-session integrations, notification summaries, online community themes, and per-app icon packs are represented by settings/entry points but are not fully integrated yet. Calendar agenda and usage-based sorting now have real implementations, subject to user-granted Android permissions. Some icon-style options are lightweight visual treatments rather than complete icon-pack implementations. Those require dedicated Android services, permissions, APIs and additional implementation. Android also restricts launchers from silently changing system-level settings.

## App icon editing, hidden apps, and app lock

This build adds these user-facing flows:

- **Per-app custom icons:** long-press an app → **Edit icon/name** → **Choose icon**, or open Settings → **App icons** → **Edit icons individually**. Pick an image from Android's document picker. The image URI is persisted so the icon can survive restarts. Use the restore option to revert to the original app icon.
- **Custom app labels:** in the same Edit app dialog, save a custom label independently of the icon.
- **Hide/unhide apps:** long-press an app → **Hide from app list**. Restore it from Settings → **Hidden apps** or Productivity → **Manage hidden apps**.
- **App lock:** long-press an app → **Lock app with PIN**. The first use asks you to create and confirm a 4–12 digit PIN. Open Settings → **App lock** to change/remove the PIN, optionally try the platform biometric prompt, and manage locked apps.

**Security boundary:** this is launcher-level app-launch gating, not an Android system-enforced application sandbox. It cannot block launches from notifications, system Settings, other launchers, or other apps. Biometric unlock requires a supported Android version/device and enrolled biometrics; PIN unlock is the fallback. Do not rely on this feature for high-security or sensitive-data protection.

## Verification note

The source archive and XML structure can be checked locally, but this environment does not have the Android SDK/Gradle installation required to produce and test an APK. Use the included GitHub Actions workflow to run a real release build; do not treat the source ZIP alone as a verified APK. New widget, notification-reply and accessibility-service integrations have not been runtime-tested on a physical Android device in this workspace.

## Additional productivity integrations (this update)

- **Weather:** enter a city in Productivity → Weather Forecast. The launcher uses Open-Meteo geocoding and forecast endpoints over HTTPS and caches the current conditions for 30 minutes. This requires an internet connection; no precise location permission is requested.
- **Media controls:** Productivity → Media Player requests Android Notification Access. When enabled, the home card can display active media-session metadata and send previous/play-pause/next commands to the active session. Support depends on the media app exposing a session and Android granting notification-listener access.
- **Notification summary:** Productivity → Notification Summary requests the same Android Notification Access and shows up to three recent notification titles/texts in memory. Notification content is sensitive; access is opt-in and can be revoked in Android Settings. This is a short recent-items list, not an AI summary or quick-reply service.
- **Focus break reminder:** Productivity → Usage Breaker schedules a one-shot Android alarm and posts a notification when the chosen interval ends. Android battery policies can delay delivery.
- **Music/email shortcuts:** Music App lists likely installed media apps; Gmail Widget opens the registered email app. These are shortcuts, not embedded third-party widgets.

## New integrations in this update

- **Third-party Android widgets:** Productivity → Add Custom Widget opens Android's system widget picker. Selected widgets are hosted inside the launcher home screen and can be removed by long-pressing the widget card. Widgets can be resized only if the host layout/device allows it; this implementation currently uses a simple vertical card layout rather than a full drag/resize workspace.
- **Gmail inbox widget:** Productivity → Gmail Widget tries to bind Gmail's installed Android widget provider. If Gmail or its provider is unavailable, the system widget picker opens so another email widget can be selected. Gmail must be installed, signed in and configured by the user.
- **Notification quick replies:** when Quick Replies is enabled and Notification Access is granted, tapping the notification card lets the user choose a recent notification and send a reply through its Android `RemoteInput` action. It only works for notifications whose app supplies an inline-reply action; not every messaging app or notification supports it.
- **Online community-theme browsing:** Themes → Community Themes queries GitHub's public repository search over HTTPS and opens selected public projects. This is online project discovery, not a curated or signed theme marketplace; themes are not automatically downloaded/applied from arbitrary repositories.
- **System-wide app-lock gate:** App lock → System-wide app lock opens Android Accessibility settings. If the user explicitly enables the service, it detects a locked app coming to the foreground and brings up the launcher PIN gate. This is still not tamper-proof OS enforcement: disabling the service, force-stopping the launcher, or some protected/system flows can bypass it. For sensitive apps, prefer Android Private Space, Secure Folder or a manufacturer-provided app lock.

## Remaining gaps compared with the recording

- A full Niagara-grade widget workspace: drag/drop placement, true resize handles, widget stacks, persistent widget configuration flows across all OEMs, and polished edge-to-edge widget layout.
- Guaranteed quick replies for every notification. Apps must publish Android inline-reply actions; the launcher cannot manufacture a reply action where the app does not provide one.
- A native Gmail inbox implementation/API integration. This project hosts Gmail's own widget if installed; it does not reimplement Gmail or access Gmail mailboxes directly.
- A curated community theme marketplace with theme preview, safe package format, install/import validation, ratings, authors and one-tap apply. Current online browsing opens public GitHub repositories.
- Tamper-proof system-wide app locking. Normal third-party Android apps cannot enforce this as a system security boundary without device-owner/enterprise privileges or OS/vendor support.
- Several advanced/proprietary Niagara features shown or implied in the video remain partial or absent: official Niagara Pro purchase/account flows, official community/support services, fully featured icon-pack integration and Icon Assistant, complete calendar/widget integrations, full usage analytics/screen-time dashboards, smart search across content, notification shade/quick-setting controls, true pop-up folders, and the video-recording overlay/control flow.
- Some appearance toggles and productivity settings are visual/basic implementations rather than complete equivalents of every Niagara feature. The exact completeness of individual flows still needs device testing.

## Build verification

The source archive can be validated locally for ZIP/XML integrity, but this workspace does not have the Android SDK/Gradle build environment available. A successful APK build and on-device runtime test have therefore not been confirmed here.

## Additional features added in the latest source update

- **Screen-time dashboard:** Settings → Screen time shows aggregate foreground use for today, the last seven days and the last 30 days, with leading apps when Usage Access is granted. Long-press an app → Screen time opens its usage details.
- **Folders and pop-ups:** Settings → Folders & Pop-ups creates named app folders. Long-press an app → Add to folder to group it. Folder cards open a pop-up list, and folder membership, rename and deletion can be managed in the UI.
- **Saved theme presets:** Themes → My Themes can save the current palette, clock and selected global appearance settings, apply saved presets, and delete them. The separate JSON backup remains available for full launcher preference backup/restore.
- **Installed icon-pack discovery:** App icons → Installed icon packs searches for common launcher icon-pack intent handlers and opens a discovered pack. Applying a pack's complete icon mapping is still not guaranteed; per-app custom icons remain available.
- **Back navigation:** Android Back returns from launcher settings screens to the home screen.

These are source-level additions. This workspace still lacks a configured Android SDK/Gradle build environment, so the APK has not been compiled or device-tested here.

## Next feature pass (source-level, not device-verified)

- **Smart Search suggestions:** typing a query now surfaces up to three matching installed apps and a web-search action. The web action opens the user's browser; it does not index private content or access unrelated app data.
- **Widget workspace controls:** hosted widgets now have an options menu with smaller/default/larger height presets, move-up/move-down ordering, provider configuration when offered, and removal. Widget IDs/order/size presets are saved in launcher preferences. Android widget providers can still impose their own minimum sizes, so the visual result varies by provider and device; this is not a full drag-and-drop grid workspace.
- **Help and community entry points:** community opens online theme discovery, feedback offers email/browser routes, and the changelog describes the current source-level feature set.

The above Kotlin changes have not been compiled in this environment. A successful GitHub Actions APK build and device testing are still required before treating them as verified.

## Integrated feature pass (2026-10-25)

This pass wires several previously partial settings into working source flows:

- **Quick Look:** long-press an app → Quick Look to see package name, install/update dates, and recent usage when Usage Access is enabled, with Open and App info actions.
- **Unused-app review:** Productivity → Support for Unused Apps / Find unused apps lists installed apps ordered by least recent usage and reports recent foreground time. Android Usage Access is required. The launcher does not silently uninstall or suspend apps.
- **Widget history:** successfully added widget provider packages are recorded; Settings → Widget history can re-add a widget from a previously used provider.
- **Ready-made themes:** Themes → Handy-Made Themes offers local presets for accent colour, clock style and dark/light appearance. Saved themes remain available in My Themes.
- **Icon pack application:** compatible icon-pack apps that expose a conventional `appfilter.xml` can now be selected. Matching per-app drawable resources are used where the pack exposes a compatible mapping. Individual custom icons take precedence. Not every icon pack follows the same convention, so support varies by pack.
- **Appearance controls:** the date visibility setting is now applied, search suggestions respect their own toggle, and the light palette uses a light background with darker default text.
- **Screen recording:** Advanced → Screen recording opens a preparation screen and requests Android's system screen-capture consent. After consent, a foreground MediaProjection service records the display to an MP4 in the app-specific Movies folder. A persistent notification includes Stop recording. Android shows its own consent UI; recording cannot start silently.

## Remaining platform and product limitations

- A normal Android app cannot provide tamper-proof system-level app locking; Accessibility-based foreground gating can be disabled or bypassed and should not be treated as a security boundary.
- Quick replies only work for notifications whose originating app provides a compatible `RemoteInput` action.
- Gmail inbox hosting depends on Gmail being installed and exposing its widget provider. This project does not independently authenticate to Gmail or implement Gmail's API.
- Third-party widget sizing/drag-and-drop is still a simple vertical hosted-widget layout, not a full grid-based launcher workspace with arbitrary positioning and resize handles.
- Community browsing is public GitHub project discovery, not an authenticated, curated theme marketplace with ratings, reviews and one-tap installation from arbitrary repos.
- Icon packs are applied only when the package exposes a conventional `appfilter.xml` mapping; vendor-specific formats and every icon assistant workflow are not supported.
- Official Niagara Pro account/subscription systems and proprietary Niagara services are not included.
- Recording depends on Android screen-capture consent, supported video encoder/display dimensions, foreground-service policy and available storage. The service is source-level only until a successful APK build and real-device test confirm it.

## Verification status

The source archive is checked for ZIP integrity and Android XML well-formedness. The workspace does not contain Gradle or an Android SDK installation, so Kotlin/Android compilation, APK signing, installation and runtime behavior remain **unverified**. The GitHub Actions workflow is the intended route to a real release build; do not treat a source archive as a verified APK.


## Pro-style feature pass (version 1.2.0, source-level)

This independent launcher now groups its premium-style tools under **Settings → Pro features**. Included in this source update:

- **Custom fonts:** choose system, serif, monospace, light, condensed or rounded typefaces for launcher text. These are built-in Android typefaces, not arbitrary font-file imports.
- **Widget stacks:** select up to four hosted widgets for a switchable stack; widgets remain Android AppWidgetHost instances and retain provider limitations.
- **Usage Breaker:** choose apps and a daily foreground-time threshold. With Usage Access enabled, the launcher shows a once-per-day reminder when a selected app is launched after the threshold is crossed. This is a gentle reminder, not an OS-enforced app timer.
- **Double-tap to sleep:** double-tapping the alphabet can request Android's screen-lock global action. This requires the user to enable the launcher's Accessibility Service, and devices below Android 9 fall back to Home because the lock action is unavailable there.
- **Pro-style feature hub:** one page links themes, icons, typography, widget stacks, Usage Breaker, folders, calendar/weather and music controls.

These features are source integrations and have not been verified in a release APK or on a physical device in this environment. This project does not unlock or impersonate the official Niagara Pro subscription, official Anycons catalogue, or Niagara's private services.
