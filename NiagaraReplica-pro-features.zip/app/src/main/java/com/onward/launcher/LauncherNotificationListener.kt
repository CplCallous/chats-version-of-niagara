package com.onward.launcher

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class LauncherNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = (extras.getCharSequence("android.title")?.toString() ?: "Notification").trim()
        val text = (extras.getCharSequence("android.text")?.toString() ?: "").trim()
        if (title.isBlank()) return
        synchronized(recent) {
            recent.removeAll { it.packageName == sbn.packageName && it.key == sbn.key }
            recent.add(0, RecentNotification(sbn.key, sbn.packageName.substringAfterLast('.').take(18), if (text.isBlank()) title else "$title: $text".take(100), sbn))
            while (recent.size > 12) recent.removeAt(recent.lastIndex)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(recent) { recent.removeAll { it.key == sbn.key } }
    }

    override fun onListenerDisconnected() {
        requestRebind(ComponentName(this, LauncherNotificationListener::class.java))
    }

    data class RecentNotification(val key: String, val packageName: String, val displayText: String, val sbn: StatusBarNotification)

    companion object {
        private val recent: MutableList<RecentNotification> = mutableListOf()
        fun activeNotificationsSnapshot(): List<Triple<String, String, StatusBarNotification>> = synchronized(recent) {
            recent.map { Triple(it.packageName, it.displayText, it.sbn) }
        }

        fun sendQuickReply(sbn: StatusBarNotification, message: String): Boolean {
            if (message.isBlank()) return false
            val notification = sbn.notification
            val action = notification.actions?.firstOrNull { candidate ->
                candidate.remoteInputs?.any { it.allowFreeFormInput || it.choices?.isNotEmpty() == true } == true && candidate.actionIntent != null
            } ?: return false
            val remoteInputs = action.remoteInputs ?: return false
            val fillIn = Intent()
            val results = android.os.Bundle()
            remoteInputs.forEach { input -> results.putCharSequence(input.resultKey, message) }
            RemoteInput.addResultsToIntent(remoteInputs, fillIn, results)
            return try { action.actionIntent.send(null, 0, fillIn); true } catch (_: Exception) { false }
        }
    }
}
