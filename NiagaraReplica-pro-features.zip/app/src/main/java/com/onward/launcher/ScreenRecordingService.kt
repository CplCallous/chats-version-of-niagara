package com.onward.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

/** User-consented screen recorder. Recording always remains visible via a foreground notification. */
class ScreenRecordingService : Service() {
    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var outputFile: File? = null
    private var stopped = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRecording()
            return START_NOT_STICKY
        }
        if (recorder != null) return START_NOT_STICKY
        createChannel()
        val notification = buildNotification("Preparing screen recording…")
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
        if (resultCode == 0 || data == null) { stopRecording(); return START_NOT_STICKY }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopRecording() }
            }, android.os.Handler(mainLooper))
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = (metrics.widthPixels.coerceAtLeast(2) / 2) * 2
            val height = (metrics.heightPixels.coerceAtLeast(2) / 2) * 2
            val density = metrics.densityDpi
            val movies = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: filesDir
            if (!movies.exists()) movies.mkdirs()
            outputFile = File(movies, "NiagaraReplica-${System.currentTimeMillis()}.mp4")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            recorder = r
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setVideoSize(width, height)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate((width * height * 5).coerceIn(2_000_000, 12_000_000))
            r.setOutputFile(outputFile!!.absolutePath)
            r.prepare()
            display = projection?.createVirtualDisplay("NiagaraReplicaScreenCapture", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            r.start()
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification("Screen recording is active"))
        } catch (_: Exception) {
            stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Screen recording", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val stop = Intent(this, ScreenRecordingService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.presence_video_online).setContentTitle("Niagara Replica")
            .setContentText(message).setOngoing(true).addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop recording", pending).build()).build()
    }

    private fun stopRecording() {
        if (stopped) return
        stopped = true
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        val file = outputFile
        if (file != null && file.exists() && file.length() > 0) {
            val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else @Suppress("DEPRECATION") Notification.Builder(this)
            notification.setSmallIcon(android.R.drawable.presence_video_online).setContentTitle("Screen recording saved")
                .setContentText(file.name).setAutoCancel(true)
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID + 1, notification.build())
        }
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() { stopRecording(); super.onDestroy() }

    companion object {
        const val EXTRA_RESULT_CODE = "screenResultCode"
        const val EXTRA_RESULT_DATA = "screenResultData"
        const val ACTION_STOP = "com.onward.launcher.STOP_SCREEN_RECORDING"
        private const val CHANNEL_ID = "screen_recording"
        private const val NOTIFICATION_ID = 9182
    }
}
