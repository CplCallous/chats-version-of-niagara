package com.onward.launcher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.Build

/** Opt-in accessibility integration to gate apps launched outside the launcher UI. */
class SystemAppLockService : AccessibilityService() {
    private var lastBlockedPackage = ""
    private var lastPromptAt = 0L
    private val lockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.onward.launcher.LOCK_SCREEN") performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }
    @Suppress("DEPRECATION")
    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter("com.onward.launcher.LOCK_SCREEN")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(lockReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(lockReceiver, filter)
    }
    override fun onDestroy() { try { unregisterReceiver(lockReceiver) } catch (_: Exception) {}; super.onDestroy() }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val target = event.packageName?.toString() ?: return
        if (target == packageName || target == "com.android.systemui") return
        val prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        val locked = prefs.getStringSet("lockedApps", emptySet()) ?: emptySet()
        if (!locked.contains(target)) return
        if (prefs.getLong("systemUnlock:$target", 0L) > System.currentTimeMillis()) return
        val now = System.currentTimeMillis()
        if (lastBlockedPackage == target && now - lastPromptAt < 1800L) return
        lastBlockedPackage = target
        lastPromptAt = now
        try {
            val gate = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("guardPackage", target)
            startActivity(gate)
        } catch (_: Exception) { performGlobalAction(GLOBAL_ACTION_HOME) }
    }

    override fun onInterrupt() {}
}
