package com.onward.launcher

import android.content.BroadcastReceiver
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build

class BreakReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "focus_breaks"
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channelId, "Focus break reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, channelId) else android.app.Notification.Builder(context)
        notification.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Time for a break")
            .setContentText("You've completed your focus interval. Stretch, hydrate, and rest your eyes.")
            .setAutoCancel(true)
        manager.notify(7204, notification.build())
    }
}
