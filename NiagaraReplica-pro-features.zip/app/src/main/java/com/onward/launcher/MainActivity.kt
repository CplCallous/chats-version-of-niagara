package com.onward.launcher

import android.app.*
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.StatusBarNotification
import android.app.usage.UsageStatsManager
import android.app.AppOpsManager
import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.provider.CalendarContract
import android.content.*
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val bg: Int get() = if (prefs.getBoolean("darkTheme", true)) Color.rgb(23, 13, 43) else Color.rgb(246, 243, 251)
    private val panel: Int get() = if (prefs.getBoolean("darkTheme", true)) Color.rgb(40, 27, 63) else Color.rgb(231, 225, 243)
    private val purple: Int get() = prefs.getInt("accent", Color.rgb(165, 139, 255))
    private val muted: Int get() = if (prefs.getBoolean("darkTheme", true)) Color.rgb(190, 178, 218) else Color.rgb(91, 82, 111)
    private lateinit var root: LinearLayout
    private var currentPage = "home"
    private var searchQuery = ""
    private val requestWallpaper = 4101
    private val requestImport = 4102
    private val requestExport = 4103
    private val requestCustomIcon = 4105
    private val requestWidgetPick = 4110
    private val requestWidgetBind = 4111
    private val requestWidgetConfigure = 4112
    private val requestRecordingCapture = 4113
    private val appWidgetHostId = 0x4E494147
    private val widgetHost by lazy { AppWidgetHost(this, appWidgetHostId) }
    private val widgetManager by lazy { AppWidgetManager.getInstance(this) }
    private var editingIconPackage: String? = null
    private val requestCalendarPermission = 4104
    private var apps: List<LaunchApp> = emptyList()
    private val clockHandler = android.os.Handler()
    private val clockTick = object : Runnable { override fun run() { if (currentPage == "home") updateClock(); clockHandler.postDelayed(this, 30_000) } }

    data class LaunchApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor = bg; window.navigationBarColor = bg; loadApps(); applyWindowPreferences(); widgetHost.startListening(); showHome(); clockHandler.post(clockTick); handleGuardIntent(intent) }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); setIntent(intent); handleGuardIntent(intent) }
    private fun handleGuardIntent(intent: Intent?) { val pkg = intent?.getStringExtra("guardPackage") ?: return; val until = prefs.getLong("systemUnlock:$pkg", 0L); if (until > System.currentTimeMillis()) return; val app = apps.firstOrNull { it.packageName == pkg } ?: return; showPinUnlock(app) }
    @Deprecated("Activity result API kept compatible with this minimal project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == requestRecordingCapture) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    val service = Intent(this, ScreenRecordingService::class.java)
                        .putExtra(ScreenRecordingService.EXTRA_RESULT_CODE, resultCode)
                        .putExtra(ScreenRecordingService.EXTRA_RESULT_DATA, data)
                    if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                    info("Screen recording", "Recording is starting. Use the persistent recording notification to stop it. Videos are saved in this app's Movies folder.")
                } catch (_: Exception) { info("Screen recording", "Android did not allow the recording service to start.") }
            }
            return
        }
        if (requestCode == requestWidgetPick || requestCode == requestWidgetBind || requestCode == requestWidgetConfigure) {
            val widgetId = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
            if (widgetId >= 0) {
                val info = widgetManager.getAppWidgetInfo(widgetId)
                if (info != null && requestCode != requestWidgetConfigure && info.configure != null) {
                    try { startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).setComponent(info.configure).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId), requestWidgetConfigure) }
                    catch (_: Exception) { saveWidgetId(widgetId) }
                } else if (info != null) saveWidgetId(widgetId) else widgetHost.deleteAppWidgetId(widgetId)
            }
            return
        }
        if (data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            requestWallpaper -> try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                prefs.edit().putString("wallpaperUri", uri.toString()).apply()
                showHome()
            } catch (e: Exception) { info("Wallpaper", "Could not save that image. Please choose another image.") }
            requestImport -> importSettings(uri)
            requestExport -> exportSettings(uri)
            requestCustomIcon -> try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                editingIconPackage?.let { pkg -> prefs.edit().putString("icon:$pkg", uri.toString()).apply() }
                editingIconPackage = null
                showIconStyles()
            } catch (_: Exception) { info("Custom icon", "Could not save that image. Choose an image from the system photo picker.") }
        }
    }
    override fun onResume() { super.onResume(); loadApps(); if (currentPage == "home") showHome() }
    @Deprecated("Use predictive back on newer Android versions")
    override fun onBackPressed() { if (currentPage != "home") showHome() else super.onBackPressed() }
    override fun onDestroy() { clockHandler.removeCallbacks(clockTick); try { widgetHost.stopListening() } catch (_: Exception) {}; super.onDestroy() }

    private fun loadApps() {
        val pm = packageManager
        apps = try { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).mapNotNull {
            val ai = it.activityInfo.applicationInfo
            if (ai.packageName == packageName) null else LaunchApp(it.loadLabel(pm).toString(), ai.packageName, it.loadIcon(pm))
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) } } catch (_: Exception) { emptyList() }
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size
        setTextColor(if (!prefs.getBoolean("darkTheme", true) && color == Color.WHITE) Color.rgb(34, 28, 45) else color)
        val family = when (prefs.getString("fontFamily", "system")) {
            "serif" -> Typeface.SERIF; "monospace" -> Typeface.MONOSPACE
            "sans-serif-light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            "sans-serif-condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            "rounded" -> Typeface.create("sans-serif-rounded", Typeface.NORMAL)
            else -> Typeface.DEFAULT
        }
        setTypeface(family, if (bold) Typeface.BOLD else Typeface.NORMAL); gravity = Gravity.CENTER_VERTICAL
    }
    private fun column(padding: Int = 0) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(padding), dp(padding), dp(padding), dp(padding)) }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun base(title: String? = null) {
        root = column().apply { setBackgroundColor(bg); layoutParams = LinearLayout.LayoutParams(-1, -1) }
        setContentView(root)
        if (title != null) {
            val header = row().apply { setPadding(dp(16), dp(12), dp(16), dp(12)) }
            val back = text("‹", 32f, purple, true); back.gravity = Gravity.CENTER; header.addView(back, LinearLayout.LayoutParams(dp(42), dp(42))); back.setOnClickListener { showHome() }
            val t = text(title, 19f, Color.WHITE, true); header.addView(t, LinearLayout.LayoutParams(0, dp(42), 1f)); root.addView(header)
        }
    }
    private fun showHome() {
        currentPage = "home"; window.statusBarColor = bg; window.navigationBarColor = bg; base()
        applyWindowPreferences()
        applyHomeBackground()
        val top = column(18).apply { setPadding(dp(18), dp(12), dp(12), dp(0)) }
        val clock = text("", clockTextSize(), Color.WHITE, prefs.getInt("clockStyle", 0) == 5); clock.tag = "clock"; top.addView(clock)
        val date = text("", 13f, if (prefs.getBoolean("darkTheme", true)) muted else Color.DKGRAY); date.tag = "date"; if (prefs.getInt("clockStyle", 0) != 7 && prefs.getBoolean("showDate", true)) top.addView(date)
        root.addView(top)
        val search = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(muted); setTextColor(Color.WHITE); textSize = 14f; singleLine = true
            setPadding(dp(16), 0, dp(12), 0); background = shape(panel, 24); setText(searchQuery)
            addTextChangedListener(object : android.text.TextWatcher { override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}; override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString() ?: ""; renderApps() }; override fun afterTextChanged(s: android.text.Editable?) {} })
        }
        val searchWrap = column().apply { setPadding(dp(12), dp(8), dp(38), dp(8)) }; searchWrap.addView(search, LinearLayout.LayoutParams(-1, dp(42))); root.addView(searchWrap)
        if (prefs.getBoolean("calendarAgenda", false) || prefs.getBoolean("calendarPreview", false)) addCalendarPreview(root)
        if (prefs.getBoolean("weather", false)) addWeatherCard(root)
        if (prefs.getBoolean("mediaPlayer", false)) addMediaCard(root)
        if (prefs.getBoolean("notificationSummary", false) || prefs.getBoolean("quickReplies", false)) addNotificationSummary(root)
        if (prefs.getStringSet("hostedWidgetIds", emptySet())?.isNotEmpty() == true) addHostedWidgets(root)
        if (prefs.getBoolean("batteryPercent", false)) addBatteryIndicator(root)
        val content = row().apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val listScroll = ScrollView(this).apply { isFillViewport = true }; val list = column(12); list.tag = "app-list"; listScroll.addView(list)
        content.addView(listScroll, LinearLayout.LayoutParams(0, -1, 1f))
        if (prefs.getBoolean("showAlphabet", true)) {
            val alphabet = column().apply { gravity = Gravity.CENTER; setPadding(0, dp(4), dp(3), dp(4)) }
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ".forEach { ch -> val letter = text(ch.toString(), 9f, muted, true).apply {
                gravity = Gravity.CENTER
                val detector = android.view.GestureDetector(this@MainActivity, object : android.view.GestureDetector.SimpleOnGestureListener() {
                    override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                        if (prefs.getBoolean("doubleTapSleep", false)) {
                            sendBroadcast(Intent("com.onward.launcher.LOCK_SCREEN").setPackage(packageName)); return true
                        }; return false
                    }
                })
                setOnTouchListener { _, event -> if (detector.onTouchEvent(event)) true else { if (event.action == MotionEvent.ACTION_UP) { searchQuery = ch.toString(); search.setText(searchQuery); search.setSelection(search.text.length); listScroll.post { listScroll.smoothScrollTo(0, findLetterY(list, ch)) } }; true } }
            }; alphabet.addView(letter, LinearLayout.LayoutParams(dp(18), 0, 1f)) }
            content.addView(alphabet, LinearLayout.LayoutParams(dp(21), -1))
        }
        root.addView(content)
        val footer = row().apply { setPadding(dp(18), dp(7), dp(18), dp(8)); background = shape(panel, 26) }
        val settings = text("⚙", 20f, purple, true); settings.gravity = Gravity.CENTER; footer.addView(settings, LinearLayout.LayoutParams(dp(40), dp(34))); settings.setOnClickListener { showSettingsHome() }
        val label = text("Niagara settings", 13f, muted); footer.addView(label, LinearLayout.LayoutParams(0, dp(34), 1f)); label.setOnClickListener { showSettingsHome() }
        val menu = text("⋮", 24f, purple, true); menu.gravity = Gravity.CENTER; footer.addView(menu, LinearLayout.LayoutParams(dp(32), dp(34))); menu.setOnClickListener { showSettingsHome() }
        val fw = column().apply { setPadding(dp(8), dp(0), dp(8), dp(8)) }; fw.addView(footer); root.addView(fw)
        renderApps(); updateClock()
    }
    private fun clockTextSize(): Float = when (prefs.getInt("clockStyle", 0)) { 1 -> 48f; 2 -> 27f; 5 -> 38f; 6 -> 34f; else -> 36f }
    private fun updateClock() {
        if (!::root.isInitialized) return
        val style = prefs.getInt("clockStyle", 0)
        val clock = root.findViewWithTag<TextView>("clock")
        val date = root.findViewWithTag<TextView>("date")
        if (clock != null) {
            clock.text = when (style) {
                7 -> ""
                2 -> SimpleDateFormat(if (prefs.getBoolean("24hour", false)) "HH:mm" else "h:mm a", Locale.getDefault()).format(Date())
                3 -> SimpleDateFormat(if (prefs.getBoolean("24hour", false)) "HH:mm · EEE, d MMM" else "h:mm a · EEE, d MMM", Locale.getDefault()).format(Date())
                4 -> SimpleDateFormat(if (prefs.getBoolean("24hour", false)) "HH:mm" else "h:mm", Locale.getDefault()).format(Date()).replace(":", "\n")
                6 -> SimpleDateFormat(if (prefs.getBoolean("24hour", false)) "h:mm a" else "h:mm", Locale.getDefault()).format(Date())
                else -> SimpleDateFormat(if (prefs.getBoolean("24hour", false)) "HH:mm" else "h:mm", Locale.getDefault()).format(Date())
            }
            clock.textSize = clockTextSize()
            clock.setTypeface(clock.typeface, if (style == 5) Typeface.BOLD else Typeface.NORMAL)
            clock.visibility = if (style == 7) View.GONE else View.VISIBLE
        }
        if (date != null) {
            date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            date.visibility = if (style == 3 || style == 7 || !prefs.getBoolean("showDate", true)) View.GONE else View.VISIBLE
        }
    }
    private fun applyWindowPreferences() {
        if (prefs.getBoolean("hideStatus", false)) window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setImmersive(prefs.getBoolean("hideNavigation", false))
    }
    private fun applyHomeBackground() {
        if (!::root.isInitialized) return
        val uriText = prefs.getString("wallpaperUri", null)
        if (uriText.isNullOrBlank()) { root.setBackgroundColor(bg); return }
        try {
            val uri = Uri.parse(uriText)
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            val targetW = resources.displayMetrics.widthPixels.coerceAtLeast(1)
            val targetH = resources.displayMetrics.heightPixels.coerceAtLeast(1)
            var sample = 1
            while (opts.outWidth / sample > targetW * 2 || opts.outHeight / sample > targetH * 2) sample *= 2
            val bitmap = BitmapFactory.Options().let { options -> options.inSampleSize = sample; contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) } }
            if (bitmap != null) root.background = BitmapDrawable(resources, bitmap).apply { gravity = Gravity.FILL }
            else root.setBackgroundColor(bg)
        } catch (_: Exception) { root.setBackgroundColor(bg) }
    }
    private fun findLetterY(list: LinearLayout, ch: Char): Int { for (i in 0 until list.childCount) { val v = list.getChildAt(i); if (v.tag == "letter:$ch") return v.top }; return 0 }
    private fun renderApps() {
        if (!::root.isInitialized || currentPage != "home") return
        val list = root.findViewWithTag<LinearLayout>("app-list") ?: return; list.removeAllViews()
        val favs = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        val query = searchQuery.trim()
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        var shown = apps.filter { !hidden.contains(it.packageName) }.map { it.copy(label = prefs.getString("name:${it.packageName}", it.label) ?: it.label) }.filter { it.label.contains(query, true) || it.packageName.contains(query, true) }
        if (prefs.getBoolean("sortUsage", false) && hasUsageAccess()) {
            val now = System.currentTimeMillis()
            val usage = try { (getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager).queryAndAggregateUsageStats(now - 7L * 24 * 60 * 60 * 1000, now) } catch (_: Exception) { emptyMap() }
            shown = shown.sortedByDescending { usage[it.packageName]?.totalTimeInForeground ?: 0L }
        }
        val favorites = if (prefs.getBoolean("showFavorites", true)) shown.filter { favs.contains(it.packageName) } else emptyList()
        if (query.isNotBlank() && prefs.getBoolean("smartSearch", true) && prefs.getBoolean("searchSuggestions", true)) {
            val suggestion = column(10).apply { background = shape(panel, 14) }
            suggestion.addView(text("Search suggestions", 11f, muted, true))
            val appMatches = shown.take(3)
            appMatches.forEach { app ->
                val item = row().apply { setPadding(dp(6), dp(5), dp(6), dp(5)) }
                item.addView(text("↗", 18f, purple, true), LinearLayout.LayoutParams(dp(28), dp(32)))
                item.addView(text(app.label, 13f, Color.WHITE), LinearLayout.LayoutParams(0, dp(32), 1f))
                item.setOnClickListener { launchApp(app) }; suggestion.addView(item)
            }
            val web = row().apply { setPadding(dp(6), dp(5), dp(6), dp(5)) }
            web.addView(text("⌕", 21f, purple, true), LinearLayout.LayoutParams(dp(28), dp(34)))
            web.addView(text("Search the web for ‘$query’", 13f, Color.WHITE), LinearLayout.LayoutParams(0, dp(34), 1f))
            web.setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))) } catch (_: Exception) { info("Search", "No browser is available.") } }
            suggestion.addView(web)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(4), dp(4), dp(4), dp(10)); list.addView(suggestion, lp)
        }
        if (query.isEmpty() && prefs.getBoolean("folders", true)) {
            val folderNames = prefs.getStringSet("folderNames", emptySet()) ?: emptySet()
            if (folderNames.isNotEmpty()) {
                list.addView(text("Folders", 12f, muted, true).apply { setPadding(dp(10), dp(5), 0, dp(8)) })
                folderNames.sorted().forEach { folder ->
                    val members = (prefs.getStringSet("folder:$folder", emptySet()) ?: emptySet()).mapNotNull { pkg -> shown.firstOrNull { it.packageName == pkg } }
                    if (members.isNotEmpty()) {
                        val folderRow = row().apply { setPadding(dp(10), dp(7), dp(8), dp(7)); background = shape(panel, 14) }
                        val glyph = text("▦", 23f, purple, true); folderRow.addView(glyph, LinearLayout.LayoutParams(dp(38), dp(38)))
                        val label = column(); label.addView(text(folder, 14f, Color.WHITE, true)); label.addView(text("${members.size} apps · tap to open", 11f, muted)); folderRow.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                        folderRow.setOnClickListener { showFolderPopup(folder, members) }
                        folderRow.setOnLongClickListener { AlertDialog.Builder(this).setTitle(folder).setItems(arrayOf("Open folder", "Rename folder", "Delete folder")) { _, which -> when(which) { 0 -> showFolderPopup(folder, members); 1 -> renameFolder(folder); 2 -> deleteFolder(folder) } }.show(); true }
                        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(6); list.addView(folderRow, lp)
                    }
                }
                list.addView(space(8))
            }
        }
        if (favorites.isNotEmpty() && query.isEmpty()) { list.addView(text("Favorites", 12f, muted, true).apply { setPadding(dp(10), dp(5), 0, dp(8)) }); favorites.forEach { addAppRow(list, it) }; list.addView(space(12)) }
        var last = '\u0000'
        shown.forEach { app -> val initial = app.label.firstOrNull()?.uppercaseChar() ?: '#'; if (initial != last) { val label = text(initial.toString(), 10f, purple, true).apply { tag = "letter:$initial"; setPadding(dp(10), dp(10), 0, dp(3)) }; list.addView(label); last = initial }; addAppRow(list, app) }
        if (shown.isEmpty()) list.addView(text("No apps found", 14f, muted).apply { setPadding(dp(12), dp(22), 0, 0) })
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun addAppRow(list: LinearLayout, app: LaunchApp) {
        val r = row().apply { setPadding(dp(8), dp(5), dp(8), dp(5)); minimumHeight = dp(48) }
        val chosenIcon = prefs.getString("icon:${app.packageName}", null)?.let { uriText ->
            try { contentResolver.openInputStream(Uri.parse(uriText))?.use { android.graphics.drawable.Drawable.createFromStream(it, null) } } catch (_: Exception) { null }
        } ?: iconFromSelectedPack(app) ?: app.icon
        val icon = ImageView(this).apply {
            setImageDrawable(chosenIcon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            when (prefs.getInt("iconStyle", 0)) {
                1 -> { background = shape(prefs.getInt("accent", purple), 50); setPadding(dp(4), dp(4), dp(4), dp(4)) }
                2 -> { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(prefs.getInt("accent", purple)) }; setPadding(dp(5), dp(5), dp(5), dp(5)) }
                3 -> { background = shape(panel, 7); setPadding(dp(4), dp(4), dp(4), dp(4)); alpha = 0.92f }
                4 -> { background = shape(prefs.getInt("accent", purple), 10); setPadding(dp(4), dp(4), dp(4), dp(4)) }
                5 -> { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(panel) }; setPadding(dp(4), dp(4), dp(4), dp(4)) }
                6 -> { background = shape(Color.WHITE, 8); setPadding(dp(2), dp(2), dp(2), dp(2)) }
                7 -> alpha = 0.58f
                8 -> { background = shape(panel, 50); setPadding(dp(4), dp(4), dp(4), dp(4)); setColorFilter(prefs.getInt("accent", purple), android.graphics.PorterDuff.Mode.SRC_ATOP) }
            }
        }
        r.addView(icon, LinearLayout.LayoutParams(dp(30), dp(30)))
        val label = text(app.label, 14f, Color.WHITE); label.setPadding(dp(12), 0, 0, 0); if (!prefs.getBoolean("hideLabels", false)) r.addView(label, LinearLayout.LayoutParams(0, dp(38), 1f))
        r.setOnClickListener { launchApp(app) }; r.setOnLongClickListener { showAppActions(app, r); true }
        list.addView(r)
    }
    private fun launchApp(app: LaunchApp) {
        if (maybeShowUsageBreaker(app)) return
        val locked = prefs.getStringSet("lockedApps", emptySet()) ?: emptySet()
        if (locked.contains(app.packageName)) { authenticateForApp(app); return }
        launchAppDirect(app)
    }
    private fun launchAppDirect(app: LaunchApp) { try { prefs.edit().putLong("systemUnlock:${app.packageName}", System.currentTimeMillis() + 30_000L).apply(); val intent = packageManager.getLaunchIntentForPackage(app.packageName); if (intent != null) startActivity(intent) else Toast.makeText(this, "Couldn't open ${app.label}", Toast.LENGTH_SHORT).show() } catch (_: Exception) { Toast.makeText(this, "Couldn't open ${app.label}", Toast.LENGTH_SHORT).show() } }
    private fun showAppActions(app: LaunchApp, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(if ((prefs.getStringSet("favorites", emptySet()) ?: emptySet()).contains(app.packageName)) "Remove from favorites" else "Edit favorites")
        if (prefs.getBoolean("quickLook", true)) popup.menu.add("Quick Look")
        popup.menu.add("App info"); popup.menu.add("Screen time"); popup.menu.add("Add to folder"); popup.menu.add("Uninstall"); popup.menu.add("Edit icon/name"); popup.menu.add("Hide from app list")
        val isLocked = (prefs.getStringSet("lockedApps", emptySet()) ?: emptySet()).contains(app.packageName)
        popup.menu.add(if (isLocked) "Unlock app" else "Lock app with PIN")
        popup.setOnMenuItemClickListener { item -> when (item.title.toString()) {
            "Edit favorites", "Remove from favorites" -> { val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet(); if (!set.add(app.packageName)) set.remove(app.packageName); prefs.edit().putStringSet("favorites", set).apply(); renderApps() }
            "Quick Look" -> showQuickLook(app)
            "App info" -> openAppInfo(app)
            "Screen time" -> showScreenTimeDashboard(app)
            "Add to folder" -> showAddToFolder(app)
            "Uninstall" -> try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))) } catch (_: Exception) {}
            "Edit icon/name" -> showEditApp(app)
            "Hide from app list" -> { val set = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet(); set.add(app.packageName); prefs.edit().putStringSet("hidden", set).apply(); loadApps(); renderApps() }
            "Lock app with PIN" -> { if (prefs.getString("pinHash", null).isNullOrBlank()) setupPin { lockApp(app) } else lockApp(app) }
            "Unlock app" -> { val set = (prefs.getStringSet("lockedApps", emptySet()) ?: emptySet()).toMutableSet(); set.remove(app.packageName); prefs.edit().putStringSet("lockedApps", set).apply(); Toast.makeText(this, "${app.label} unlocked", Toast.LENGTH_SHORT).show() }
        }; true }; popup.show()
    }
    private fun openAppInfo(app: LaunchApp) { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))) } catch (_: Exception) {} }
    private fun showEditApp(app: LaunchApp) {
        val input = EditText(this).apply { setText(prefs.getString("name:${app.packageName}", app.label)); hint = "App name" }
        val box = column(8); box.addView(input)
        AlertDialog.Builder(this).setTitle("Edit app").setView(box)
            .setPositiveButton("Save name") { _, _ -> prefs.edit().putString("name:${app.packageName}", input.text.toString().trim().ifBlank { app.label }).apply(); showHome() }
            .setNeutralButton("Choose icon") { _, _ -> chooseCustomIcon(app.packageName) }
            .setNegativeButton("More", null).show().also { dialog ->
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                    AlertDialog.Builder(this).setTitle("Icon options").setItems(arrayOf("Choose image from gallery", "Restore original icon", "Cancel")) { _, which ->
                        when (which) { 0 -> chooseCustomIcon(app.packageName); 1 -> { prefs.edit().remove("icon:${app.packageName}").apply(); showHome() } }
                    }.show(); dialog.dismiss()
                }
            }
    }
    private fun chooseCustomIcon(pkg: String) {
        editingIconPackage = pkg
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        try { startActivityForResult(intent, requestCustomIcon) } catch (_: Exception) { info("Custom icon", "Could not open the image picker.") }
    }
    private fun lockApp(app: LaunchApp) {
        val set = (prefs.getStringSet("lockedApps", emptySet()) ?: emptySet()).toMutableSet(); set.add(app.packageName); prefs.edit().putStringSet("lockedApps", set).apply()
        Toast.makeText(this, "${app.label} is now locked", Toast.LENGTH_SHORT).show()
    }
    private fun setupPin(onReady: () -> Unit) {
        val first = EditText(this).apply { inputType = 2; hint = "Create a 4–12 digit PIN" }
        AlertDialog.Builder(this).setTitle("Set app-lock PIN").setMessage("This PIN protects apps launched through this launcher.").setView(first).setNegativeButton("Cancel", null).setPositiveButton("Continue") { _, _ ->
            val pin = first.text.toString()
            if (pin.length !in 4..12 || pin.any { !it.isDigit() }) { info("Invalid PIN", "Use 4–12 digits."); return@setPositiveButton }
            val confirm = EditText(this).apply { inputType = 2; hint = "Confirm PIN" }
            AlertDialog.Builder(this).setTitle("Confirm PIN").setView(confirm).setNegativeButton("Cancel", null).setPositiveButton("Save PIN") { _, _ ->
                if (confirm.text.toString() != pin) info("PIN mismatch", "The PINs did not match. Please try again.") else {
                    val salt = UUID.randomUUID().toString(); prefs.edit().putString("pinSalt", salt).putString("pinHash", hashPin(pin, salt)).apply(); onReady()
                }
            }.show()
        }.show()
    }
    private fun hashPin(pin: String, salt: String): String = java.security.MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    private fun authenticateForApp(app: LaunchApp) {
        if (prefs.getBoolean("useBiometrics", false) && android.os.Build.VERSION.SDK_INT >= 28) {
            try {
                val prompt = android.hardware.biometrics.BiometricPrompt.Builder(this).setTitle("Unlock ${app.label}").setSubtitle("Verify your identity to open this app").setNegativeButton("Use PIN", mainExecutor) { _, _ -> showPinUnlock(app) }.build()
                prompt.authenticate(android.os.CancellationSignal(), mainExecutor, object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) { launchAppDirect(app) }
                    override fun onAuthenticationFailed() { Toast.makeText(this@MainActivity, "Biometric not recognized", Toast.LENGTH_SHORT).show() }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) { if (errorCode != 13 && errorCode != 10) showPinUnlock(app) }
                })
                return
            } catch (_: Exception) { /* PIN fallback below */ }
        }
        showPinUnlock(app)
    }
    private fun showPinUnlock(app: LaunchApp) {
        val input = EditText(this).apply { inputType = 2; hint = "Enter app-lock PIN" }
        AlertDialog.Builder(this).setTitle("Unlock ${app.label}").setView(input).setCancelable(false).setNegativeButton("Cancel", null).setPositiveButton("Unlock") { _, _ ->
            val salt = prefs.getString("pinSalt", "") ?: ""
            val expected = prefs.getString("pinHash", "") ?: ""
            if (hashPin(input.text.toString(), salt) == expected && expected.isNotBlank()) launchAppDirect(app) else info("Incorrect PIN", "That PIN is incorrect. The app remains locked.")
        }.show()
    }
    private fun showAppLockSettings() {
        currentPage = "app-lock"; base("App lock"); val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        body.addView(text("Protect apps opened through this launcher with a PIN. Biometric unlock is optional when supported by the device.", 12f, muted))
        settingCard(body, "Set or change PIN", "Use a 4–12 digit app-lock PIN") { setupPin { showAppLockSettings() } }
        settingCard(body, "Remove app-lock PIN", "Unlock all protected apps and remove the PIN") { AlertDialog.Builder(this).setTitle("Remove app lock?").setMessage("This removes the PIN and unlocks every app protected by this launcher.").setNegativeButton("Cancel", null).setPositiveButton("Remove") { _, _ -> prefs.edit().remove("pinHash").remove("pinSalt").remove("lockedApps").putBoolean("useBiometrics", false).apply(); showAppLockSettings() }.show() }
        toggle(body, "Use biometrics when available", "Try fingerprint or face authentication before PIN", "useBiometrics", false)
        settingCard(body, "Manage locked apps", "Lock or unlock individual apps") { showLockedApps() }
      settingCard(body, "System-wide app lock", "Require the launcher PIN when protected apps are opened elsewhere") { info("Enable system-wide protection", "Android requires you to explicitly enable the Niagara Replica accessibility service. It watches which app is foregrounded and brings up the PIN gate for apps you locked. This is not tamper-proof and can be bypassed by disabling the service or force-stopping the launcher.") ; try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {} }
        settingCard(body, "Important limitation", "Launcher-level protection does not prevent opening apps through Android Settings, notifications, other launchers, or system intents") { info("App lock limitation", "This is launcher-level protection only, not an operating-system sandbox. For stronger protection, use Android's built-in Private Space, Secure Folder, or device manufacturer app lock if available.") }
    }
    private fun showLockedApps() {
        currentPage = "locked-apps"; base("Locked apps"); val body = column(10); root.addView(ScrollView(this).apply { addView(body) })
        val locked = prefs.getStringSet("lockedApps", emptySet()) ?: emptySet()
        val candidates = apps.filter { locked.contains(it.packageName) }
        if (candidates.isEmpty()) body.addView(text("No apps are locked yet. Long-press an app on the home screen and choose Lock app with PIN.", 13f, muted))
        candidates.forEach { app -> settingCard(body, prefs.getString("name:${app.packageName}", app.label) ?: app.label, "Tap to unlock this app") { val set = (prefs.getStringSet("lockedApps", emptySet()) ?: emptySet()).toMutableSet(); set.remove(app.packageName); prefs.edit().putStringSet("lockedApps", set).apply(); showLockedApps() } }
    }

    private fun showSettingsHome() { currentPage = "settings"; base("Niagara settings")
        val sc = ScrollView(this); val body = column(18); sc.addView(body); root.addView(sc)
        body.addView(text("Free version", 12f, muted).apply { setPadding(dp(8), dp(0), 0, dp(12)) })
        settingCard(body, "Productivity", "Quick replies, calendar and media player") { showProductivity() }
        settingCard(body, "Themes", "Create your own home screen style") { showThemes() }
        settingCard(body, "Pro features", "Themes, Anycons-style icons, fonts, widget stacks and Usage Breaker") { showProFeatures() }
        settingCard(body, "Help & feedback", "Tips, support and feedback") { AlertDialog.Builder(this).setTitle("Help & feedback").setItems(arrayOf("Read project README", "Report an issue on GitHub", "Send feedback by email")) { _, which -> when (which) { 0 -> info("Help", "See README.md in the source project for setup, permissions and known limitations."); 1 -> openExternal("https://github.com/search?q=NiagaraReplica&type=repositories"); 2 -> try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).putExtra(Intent.EXTRA_SUBJECT, "Niagara Replica feedback")) } catch (_: Exception) { info("Feedback", "No email app is available.") } } }.show() }
        settingCard(body, "Community", "Browse themes and public projects") { showCommunityThemes() }
        settingCard(body, "App icons", "Choose icon styles, installed packs or custom images") { showIconStyles() }
        settingCard(body, "Hidden apps", "Manage apps removed from the home list") { showHiddenApps() }
        settingCard(body, "Recording controls", "Open the screen-recording preparation flow") { startScreenRecordingFlow() }
        settingCard(body, "App lock", "Set a PIN and protect selected apps") { showAppLockSettings() }
        settingCard(body, "Screen time", "Usage today and the last seven days") { showScreenTimeDashboard(null) }
        settingCard(body, "Unused apps", "Find apps you rarely open") { showUnusedApps() }
        settingCard(body, "Widget history", "Recently added Android widgets") { showWidgetHistory() }
        settingCard(body, "Folders & Pop-ups", "Create folders and group apps") { showFolderManager() }
        settingCard(body, "Advanced", "App info, backup, reset and system options") { showAdvanced() }
    }
    private fun settingCard(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) { val card = column(14).apply { background = shape(panel, 18); setOnClickListener { action() } }; card.addView(text(title, 16f, Color.WHITE, true)); card.addView(text(subtitle, 12f, muted).apply { setPadding(0, dp(5), 0, 0) }); val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); parent.addView(card, lp) }
    private fun showProFeatures() {
        currentPage = "pro-features"; base("Pro features")
        val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        body.addView(text("Premium-style features implemented locally in NiagaraReplica. This is an independent launcher project, not an official Niagara subscription or account integration.", 12f, muted))
        settingCard(body, "Themes and community themes", "Saved presets, ready-made themes and online theme discovery") { showThemes() }
        settingCard(body, "Icon styles and Icon Assistant", "Dots, built-in treatments, custom icons and compatible icon packs") { showIconStyles() }
        settingCard(body, "Custom fonts and clock", "Personalize typography, clock and date") { showFontStyles() }
        settingCard(body, "Widget stacks", "Group up to four hosted widgets in a switchable stack") { showWidgetStackManager() }
        settingCard(body, "Calendar and weather", "Agenda, preview and forecast cards") { showProductivity() }
        settingCard(body, "Usage Breaker", "Set per-app daily usage limits and gentle reminders") { showUsageBreakerSetup() }
        settingCard(body, "Pop-up folders", "Organize apps into compact pop-up folders") { showFolderManager() }
        settingCard(body, "Double-tap to sleep", "Configure the alphabet gesture and Accessibility permission") { showGlobalSettings() }
        settingCard(body, "Hide status bar", "Use a cleaner full-screen home screen") { showGlobalSettings() }
        settingCard(body, "Music apps", "Find installed music apps and access media controls") { showProductivity() }
    }

    private fun showProductivity() { currentPage = "productivity"; base("Productivity"); val sc = ScrollView(this); val body = column(16); sc.addView(body); root.addView(sc)
        body.addView(text("Customize the launcher experience", 12f, muted).apply { setPadding(0, 0, 0, dp(12)) })
        toggle(body, "Quick Replies", "Reply to supported notifications from the launcher", "quickReplies", false) { if (prefs.getBoolean("quickReplies", false)) requestNotificationAccess() }
        toggle(body, "Calendar Agenda", "Upcoming events and reminders", "calendarAgenda", false) { ensureCalendarPermission() }
        toggle(body, "Calendar Preview", "See upcoming events at a glance", "calendarPreview", false) { ensureCalendarPermission() }
        toggle(body, "Weather Forecast", "Current conditions from Open-Meteo (city required)", "weather", false) { if (prefs.getBoolean("weather", false)) showWeatherSetup() }
        toggle(body, "Media Player", "Control active Android media sessions", "mediaPlayer", false) { if (prefs.getBoolean("mediaPlayer", false)) requestNotificationAccess() }
        toggle(body, "Music App", "Quick access to installed music apps", "musicApp", false) { if (prefs.getBoolean("musicApp", false)) showMusicApps() }
        toggle(body, "Gmail Widget", "Host Gmail's official inbox widget (requires Gmail installed)", "gmailWidget", false) { if (prefs.getBoolean("gmailWidget", false)) addAndroidWidget("com.google.android.gm") }
        toggle(body, "Usage Breaker", "Choose apps and set daily usage thresholds", "usageBreaker", false) { if (prefs.getBoolean("usageBreaker", false)) showUsageBreakerSetup() }
        toggle(body, "Notification Summary", "Show recent notification titles on the home screen", "notificationSummary", false) { if (prefs.getBoolean("notificationSummary", false)) requestNotificationAccess() }
        toggle(body, "Hide Apps", "Hide selected apps from the list", "hideApps", true) { showHiddenApps() }
        settingCard(body, "Manage hidden apps", "Unhide apps and restore them to the list") { showHiddenApps() }
        section(body, "App Organization")
        toggle(body, "Folders & Pop-ups", "Group apps and open pop-up folders", "folders", true)
        toggle(body, "Support for Unused Apps", "Find apps you have not used recently", "unusedApps", false) { if (prefs.getBoolean("unusedApps", false)) showUnusedApps() }
        settingCard(body, "Find unused apps", "Review apps with little or no recent usage") { showUnusedApps() }
        toggle(body, "Sort All Apps by Usage", "Order apps by recent usage", "sortUsage", false) { if (!hasUsageAccess()) { info("Usage access required", "Allow usage access for Niagara Replica in Android Settings. App sorting will use recent usage from the last 7 days."); try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) {} } else { showHome() } }
        section(body, "Smart Search")
        toggle(body, "Smart Search", "Search apps and related information", "smartSearch", true)
        toggle(body, "Show Search Suggestions", "Suggest apps while typing", "searchSuggestions", true)
        section(body, "Quick Look")
        toggle(body, "Quick Look", "Show app details and shortcuts from the app menu", "quickLook", true)
        toggle(body, "Add Custom Widget", "Add an Android home-screen widget", "customWidget", false) { showWidgetHelp() }
        toggle(body, "Widget History", "Remember recently used widgets", "widgetHistory", false) { if (prefs.getBoolean("widgetHistory", false)) showWidgetHistory() }
        settingCard(body, "Widget history", "Recently added widgets") { showWidgetHistory() }
        settingCard(body, "Widget stacks", "Group up to four widgets into a compact stack") { showWidgetStackManager() }
        toggle(body, "Show Battery Percentage", "Display battery percentage", "batteryPercent", true)
        toggle(body, "Always Show Screen Rotation", "Keep a shortcut to Android display settings", "rotationShortcut", false) { if (prefs.getBoolean("rotationShortcut", false)) info("Screen rotation", "Android controls rotation globally. Use the quick settings Auto-rotate tile, or open Display settings below.") }
        settingCard(body, "Screen rotation settings", "Open Android display settings") { try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        toggle(body, "Show Screen Time", "Show app usage shortcuts", "showScreenTime", false) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
    }
    private fun addWeatherCard(parent: LinearLayout) {
        val city = prefs.getString("weatherCity", "") ?: ""
        val card = column(12).apply { background = shape(panel, 16); setOnClickListener { showWeatherSetup() } }
        card.addView(text("Weather · ${if (city.isBlank()) "Set your city" else city}", 14f, Color.WHITE, true))
        card.addView(text(prefs.getString("weatherSummary", "Tap to configure weather") ?: "Tap to configure weather", 12f, muted).apply { setPadding(0, dp(4), 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(14), dp(5), dp(14), dp(8)); parent.addView(card, lp)
        if (city.isNotBlank() && System.currentTimeMillis() - prefs.getLong("weatherFetchedAt", 0L) > 30 * 60 * 1000L) fetchWeather(city)
    }
    private fun showWeatherSetup() {
        val input = EditText(this).apply { setText(prefs.getString("weatherCity", "")); hint = "City (e.g. Coimbatore)"; setTextColor(Color.WHITE); setHintTextColor(muted) }
        AlertDialog.Builder(this).setTitle("Weather location").setMessage("Weather uses Open-Meteo. Enter a city name; no GPS permission is needed.").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val city = input.text.toString().trim(); if (city.isNotBlank()) { prefs.edit().putString("weatherCity", city).putString("weatherSummary", "Fetching forecast…").apply(); fetchWeather(city); showHome() }
            else { prefs.edit().putString("weatherCity", "").apply(); showHome() }
        }.show()
    }
    private fun fetchWeather(city: String) {
        Thread {
            try {
                val encoded = java.net.URLEncoder.encode(city, "UTF-8")
                val geo = org.json.JSONObject(URL("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json").readText())
                val result = geo.optJSONArray("results")?.optJSONObject(0) ?: throw Exception("City not found")
                val lat = result.getDouble("latitude"); val lon = result.getDouble("longitude")
                val weather = org.json.JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto").readText())
                val current = weather.getJSONObject("current"); val daily = weather.getJSONObject("daily")
                val summary = "${current.optDouble("temperature_2m").toInt()}°C · Feels ${current.optDouble("apparent_temperature").toInt()}°C · Humidity ${current.optInt("relative_humidity_2m")}% · High ${daily.getJSONArray("temperature_2m_max").optDouble(0).toInt()}° / Low ${daily.getJSONArray("temperature_2m_min").optDouble(0).toInt()}°"
                prefs.edit().putString("weatherSummary", summary).putString("weatherResolvedCity", result.optString("name", city)).putLong("weatherFetchedAt", System.currentTimeMillis()).apply()
                runOnUiThread { if (currentPage == "home") showHome() }
            } catch (_: Exception) { prefs.edit().putString("weatherSummary", "Weather unavailable · tap to retry").apply(); runOnUiThread { if (currentPage == "home") showHome() } }
        }.start()
    }
    private fun addMediaCard(parent: LinearLayout) {
        val card = column(12).apply { background = shape(panel, 16) }
        val controller = activeMediaController()
        val metadata = controller?.metadata
        val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "No active media"
        val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: "Start playback in a music app"
        card.addView(text(title, 14f, Color.WHITE, true)); card.addView(text(artist, 12f, muted).apply { setPadding(0, dp(3), 0, dp(8)) })
        val controls = row(); fun mediaButton(label: String, action: (MediaController.TransportControls) -> Unit) { val b = Button(this).apply { text = label; setTextColor(Color.WHITE); background = shape(purple, 18); setOnClickListener { val c = activeMediaController(); if (c == null) requestNotificationAccess() else try { action(c.transportControls) } catch (_: Exception) { Toast.makeText(this@MainActivity, "Playback command unavailable", Toast.LENGTH_SHORT).show() }; showHome() } }; controls.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f)) }
        mediaButton("Previous") { it.skipToPrevious() }; mediaButton(if (controller?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) "Pause" else "Play") { if (controller?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) it.pause() else it.play() }; mediaButton("Next") { it.skipToNext() }
        card.addView(controls); val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(14), dp(5), dp(14), dp(8)); parent.addView(card, lp)
    }
    private fun activeMediaController(): MediaController? = try {
        val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        manager.getActiveSessions(ComponentName(this, LauncherNotificationListener::class.java)).firstOrNull { it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING } ?: manager.getActiveSessions(ComponentName(this, LauncherNotificationListener::class.java)).firstOrNull()
    } catch (_: Exception) { null }
    private fun requestNotificationAccess() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        if (!enabled.contains(packageName)) { info("Notification access", "Enable Niagara Replica in Android's Notification access settings to read notification titles and control active media sessions."); try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) {} }
        else showHome()
    }
    private fun addNotificationSummary(parent: LinearLayout) {
        val card = column(12).apply { background = shape(panel, 16); setOnClickListener { if (prefs.getBoolean("quickReplies", false)) showQuickReplyDialog() else requestNotificationAccess() } }
        card.addView(text(if (prefs.getBoolean("quickReplies", false)) "Notifications · tap to quick reply" else "Notification summary", 14f, Color.WHITE, true))
        val items = LauncherNotificationListener.activeNotificationsSnapshot().take(3)
        if (items.isEmpty()) card.addView(text("No recent notifications · tap to enable access", 12f, muted).apply { setPadding(0, dp(4), 0, 0) })
        else items.forEach { item -> card.addView(text("${item.first} · ${item.second}", 12f, muted).apply { setPadding(0, dp(4), 0, 0); maxLines = 2 }) }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(14), dp(5), dp(14), dp(8)); parent.addView(card, lp)
    }
    private fun showMusicApps() {
        val candidates = apps.filter { val s = (it.label + " " + it.packageName).lowercase(Locale.getDefault()); listOf("music", "spotify", "youtube", "soundcloud", "podcast", "player", "audio").any { word -> s.contains(word) } }
        if (candidates.isEmpty()) { info("Music apps", "No obvious music apps were found in the installed app list."); return }
        AlertDialog.Builder(this).setTitle("Open a music app").setItems(candidates.map { it.label }.toTypedArray()) { _, which -> launchApp(candidates[which]) }.show()
    }
    private fun openEmailApp() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL)
        try { startActivity(intent) } catch (_: Exception) { info("Email", "No email app is registered. Install an email app and try again.") }
    }
    private fun showBreakTimerSetup() {
        val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText("50"); hint = "Minutes"; setTextColor(Color.WHITE) }
        AlertDialog.Builder(this).setTitle("Focus break reminder").setMessage("Choose a focus duration in minutes. Android may delay reminders if battery restrictions are enabled.").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Start") { _, _ ->
            val minutes = input.text.toString().toIntOrNull()?.coerceIn(1, 240) ?: 50
            val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
            val intent = Intent(this, BreakReminderReceiver::class.java)
            val pending = PendingIntent.getBroadcast(this, 7204, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try { alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60_000L, pending); Toast.makeText(this, "Break reminder set for $minutes minutes", Toast.LENGTH_LONG).show() } catch (_: Exception) { info("Reminder", "Could not schedule the reminder.") }
        }.show()
    }

    private fun ensureCalendarPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), requestCalendarPermission)
        } else if (currentPage == "home") showHome()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCalendarPermission) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) showHome()
            else info("Calendar permission", "Calendar access is needed to show upcoming events. You can enable it later in Android Settings.")
        }
    }
    private fun addCalendarPreview(parent: LinearLayout) {
        val wrap = column(12).apply { setPadding(dp(16), dp(6), dp(16), dp(10)) }
        wrap.addView(text("UP NEXT", 10f, purple, true).apply { setPadding(0, 0, 0, dp(5)) })
        val events = readUpcomingEvents(3)
        if (events == null) {
            val card = column(12).apply { background = shape(panel, 16); setOnClickListener { ensureCalendarPermission() } }
            card.addView(text("Connect your calendar", 13f, Color.WHITE, true))
            card.addView(text("Tap to allow access and show upcoming events", 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
            wrap.addView(card)
        } else if (events.isEmpty()) {
            wrap.addView(column(10).apply { background = shape(panel, 14); addView(text("Nothing scheduled soon", 12f, muted)) })
        } else {
            events.forEach { event ->
                val card = row().apply { background = shape(panel, 14); setPadding(dp(11), dp(8), dp(10), dp(8)) }
                val time = text(event.second, 11f, purple, true).apply { gravity = Gravity.TOP }
                card.addView(time, LinearLayout.LayoutParams(dp(72), -2))
                val details = column(); details.addView(text(event.first, 12f, Color.WHITE, true)); details.addView(text(event.third, 10f, muted).apply { setPadding(0, dp(2), 0, 0) })
                card.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
                val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(5); wrap.addView(card, lp)
            }
        }
        parent.addView(wrap)
    }
    // Returns null when calendar permission is missing, otherwise a list of title/time/date rows.
    private fun readUpcomingEvents(limit: Int): List<Triple<String, String, String>>? {
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return null
        val now = System.currentTimeMillis()
        val end = now + 14L * 24 * 60 * 60 * 1000
        val result = mutableListOf<Triple<String, String, String>>()
        val projection = arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND, CalendarContract.Events.ALL_DAY, CalendarContract.Events.EVENT_LOCATION)
        val selection = "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} <= ? AND ${CalendarContract.Events.DELETED}=0"
        try {
            contentResolver.query(CalendarContract.Events.CONTENT_URI, projection, selection, arrayOf(now.toString(), end.toString()), "${CalendarContract.Events.DTSTART} ASC")?.use { cursor ->
                while (cursor.moveToNext() && result.size < limit) {
                    val title = cursor.getString(0)?.takeIf { it.isNotBlank() } ?: "Untitled event"
                    val start = cursor.getLong(1)
                    val allDay = cursor.getInt(3) != 0
                    val location = cursor.getString(4)?.takeIf { it.isNotBlank() } ?: ""
                    val time = if (allDay) "ALL DAY" else SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(start))
                    val date = if (android.text.format.DateUtils.isToday(start)) "Today" else SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(start))
                    result.add(Triple(title, "$date\n$time", location.ifBlank { date }))
                }
            }
        } catch (_: SecurityException) { return null } catch (_: Exception) { return emptyList() }
        return result
    }
    private fun showQuickReplyDialog() {
        val notices = LauncherNotificationListener.activeNotificationsSnapshot()
        if (notices.isEmpty()) { info("Quick replies", "No reply-capable notifications are currently available. Grant Notification Access and open a messaging app notification first."); requestNotificationAccess(); return }
        val labels = notices.map { "${it.first}: ${it.second}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose a notification to reply to").setItems(labels) { _, which ->
            val input = EditText(this).apply { hint = "Type a reply"; setTextColor(Color.WHITE); setHintTextColor(muted) }
            AlertDialog.Builder(this).setTitle("Quick reply").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Send") { _, _ ->
                val result = LauncherNotificationListener.sendQuickReply(notices[which].third, input.text.toString())
                Toast.makeText(this, if (result) "Reply sent" else "This notification doesn't support inline replies", Toast.LENGTH_LONG).show()
            }.show()
        }.show()
    }
    private fun addBatteryIndicator(parent: LinearLayout) {
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra("level", -1) ?: -1
        val scale = battery?.getIntExtra("scale", 100) ?: 100
        if (level >= 0 && scale > 0) parent.addView(text("▰  ${level * 100 / scale}% battery", 10f, muted).apply { gravity = Gravity.END; setPadding(0, 0, dp(18), dp(5)) })
    }
    @Suppress("DEPRECATION")
    private fun hasUsageAccess(): Boolean {
        return try {
            val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
            val mode = if (android.os.Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) { false }
    }
    private fun section(body: LinearLayout, title: String) { body.addView(text(title, 15f, purple, true).apply { setPadding(0, dp(18), 0, dp(7)) }) }
    private fun toggle(body: LinearLayout, title: String, subtitle: String, key: String, default: Boolean, action: (() -> Unit)? = null) {
        val r = row().apply { setPadding(dp(2), dp(9), 0, dp(9)) }; val texts = column().apply { addView(text(title, 14f, Color.WHITE)); addView(text(subtitle, 11f, muted).apply { setPadding(0, dp(3), 0, 0) }) }; r.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply { buttonTintList = android.content.res.ColorStateList.valueOf(purple); isChecked = prefs.getBoolean(key, default); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply(); if (action != null && checked) action() } }; r.addView(sw); body.addView(r)
    }
    private fun showThemes() { currentPage = "themes"; base("Themes"); val sc = ScrollView(this); val body = column(16); sc.addView(body); root.addView(sc)
        settingCard(body, "Create Theme", "Build a new custom home screen theme") { showThemeEditor() }
        settingCard(body, "Edit Current Theme", "Customize the theme you are using") { showThemeEditor() }
        settingCard(body, "My Themes", "Manage saved theme presets") { showSavedThemes() }
        settingCard(body, "Export / import theme", "Share a theme as a JSON file") { backupRestore() }
        settingCard(body, "Handy-Made Themes", "Apply a ready-made color and clock combination") { showHandyMadeThemes() }
        settingCard(body, "Community Themes", "Browse public theme projects online") { showCommunityThemes() }
        section(body, "Appearance")
        settingCard(body, "Theme colour", "Wallpaper and system colors") { showColorPicker() }
        settingCard(body, "Clock style", "Choose clock layout and typography") { showClockStyles() }
        settingCard(body, "Custom fonts", "Change the launcher typography") { showFontStyles() }
        settingCard(body, "App icons", "Choose icon shape and appearance") { showIconStyles() }
        settingCard(body, "Wallpaper", "Choose an image for the launcher background") { chooseLauncherWallpaper() }
    }
    private fun showThemeEditor() { currentPage = "theme-editor"; base("Create Theme"); val body = column(18); root.addView(body)
        body.addView(text("Preview", 13f, muted)); val preview = column(14).apply { background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(bg, prefs.getInt("accent", purple), bg)).apply { cornerRadius = dp(20).toFloat() }; setPadding(dp(16), dp(22), dp(16), dp(22)) }; preview.addView(text("2:43", 30f)); preview.addView(text("Sun, 25 Oct", 12f, muted)); preview.addView(text("◉  Camera\n◉  Chrome\n◉  Drive\n◉  Files", 14f)); body.addView(preview, LinearLayout.LayoutParams(-1, dp(220)))
        settingCard(body, "Global settings", "Theme, status bar and navigation") { showGlobalSettings() }; settingCard(body, "Theme colour", "Choose accent and background") { showColorPicker() }; settingCard(body, "App icons", "Icon styles and per-app icons") { showIconStyles() }; settingCard(body, "Clock style", "Choose a clock layout") { showClockStyles() }; settingCard(body, "Custom fonts", "Choose launcher typography") { showFontStyles() }; settingCard(body, "Wallpaper", "Choose a launcher background image") { chooseLauncherWallpaper() }
        button(body, "Save as My Theme") { saveCurrentTheme() }
        button(body, "Apply theme") { Toast.makeText(this, "Theme applied", Toast.LENGTH_SHORT).show(); showHome() }
    }
    private fun showGlobalSettings() { currentPage = "global"; base("Global settings"); val body = column(18); root.addView(body)
        toggle(body, "Dark Theme", "Use a dark launcher appearance", "darkTheme", true) { showGlobalSettings() }
        toggle(body, "Hide Status Bar", "Hide the Android status bar on home", "hideStatus", false) { window.setFlags(if (prefs.getBoolean("hideStatus", false)) WindowManager.LayoutParams.FLAG_FULLSCREEN else 0, WindowManager.LayoutParams.FLAG_FULLSCREEN) }
        toggle(body, "Hide Navigation Bar", "Use immersive full-screen mode", "hideNavigation", false) { setImmersive(prefs.getBoolean("hideNavigation", false)) }
        toggle(body, "Hide App Labels", "Display icons without text labels", "hideLabels", false)
        toggle(body, "Show Alphabet", "Show A–Z edge navigation", "showAlphabet", true)
        toggle(body, "Show Favorite Apps", "Keep favorites above the app list", "showFavorites", true)
        toggle(body, "24-hour clock", "Use 24-hour time format", "24hour", false) { updateClock() }
        toggle(body, "Show date", "Show the date below the clock", "showDate", true) { showHome() }
        settingCard(body, "Custom fonts", "Choose system, serif, rounded or monospace typography") { showFontStyles() }
        toggle(body, "Double-tap alphabet to sleep", "Requires enabling the launcher Accessibility Service", "doubleTapSleep", false) { if (prefs.getBoolean("doubleTapSleep", false)) { info("Enable accessibility", "Open Accessibility settings and enable Niagara Replica to allow the double-tap screen-off gesture."); try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {} } }
    }
    private fun setImmersive(on: Boolean) { window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) else View.SYSTEM_UI_FLAG_VISIBLE }
    private fun chooseLauncherWallpaper() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        try { startActivityForResult(intent, requestWallpaper) } catch (_: Exception) { info("Wallpaper", "The image picker could not be opened on this device.") }
    }
    private fun showColorPicker() { currentPage = "colors"; base("Theme colour"); val body = column(18); root.addView(body); body.addView(text("Wallpaper and system colors", 13f, muted)); val colors = listOf(0xff7965b5.toInt(),0xff4d55a8.toInt(),0xffbd65cf.toInt(),0xff009bb5.toInt(),0xff81849a.toInt(),0xfff2eee8.toInt(),0xffe96755.toInt(),0xffee9b41.toInt(),0xffe5cb4a.toInt(),0xff55bd80.toInt(),0xff55b5df.toInt(),0xff526ee2.toInt())
        val grid = android.widget.GridLayout(this).apply { columnCount = 4 }; colors.forEach { c -> val v = View(this).apply { background = GradientDrawable().apply { setColor(c); shape = GradientDrawable.OVAL; setStroke(dp(2), if (prefs.getInt("accent", purple) == c) Color.WHITE else Color.TRANSPARENT) }; setOnClickListener { prefs.edit().putInt("accent", c).apply(); Toast.makeText(this@MainActivity, "Accent colour saved", Toast.LENGTH_SHORT).show(); showColorPicker() } }; val p = android.widget.GridLayout.LayoutParams().apply { width = dp(58); height = dp(58); setMargins(dp(10), dp(10), dp(10), dp(10)) }; grid.addView(v,p) }; body.addView(grid)
        button(body, "Choose wallpaper image") { chooseLauncherWallpaper() }
        if (!prefs.getString("wallpaperUri", null).isNullOrBlank()) button(body, "Clear launcher wallpaper") { prefs.edit().remove("wallpaperUri").apply(); showColorPicker() }
    }
    private fun showFontStyles() {
        currentPage = "fonts"; base("Custom fonts")
        val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        body.addView(text("Choose a built-in typeface for launcher labels, cards and the clock. No external font files are downloaded.", 12f, muted))
        val fonts = listOf("system" to "System default", "serif" to "Serif", "monospace" to "Monospace", "sans-serif-light" to "Light", "sans-serif-condensed" to "Condensed", "rounded" to "Rounded")
        fonts.forEach { (key, label) ->
            val preview = text("$label  ·  12:45  ·  Calendar", 17f, Color.WHITE, key == prefs.getString("fontFamily", "system"))
            preview.setTypeface(when(key) { "serif" -> Typeface.SERIF; "monospace" -> Typeface.MONOSPACE; "sans-serif-light" -> Typeface.create("sans-serif-light", 0); "sans-serif-condensed" -> Typeface.create("sans-serif-condensed", 0); "rounded" -> Typeface.create("sans-serif-rounded", 0); else -> Typeface.DEFAULT })
            val card = column(14).apply { background = shape(panel, 16); addView(preview); addView(text(if (key == prefs.getString("fontFamily", "system")) "Selected" else "Tap to apply", 11f, muted)) }
            card.setOnClickListener { prefs.edit().putString("fontFamily", key).apply(); showFontStyles() }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8); body.addView(card, lp)
        }
    }

    private fun showUsageBreakerSetup() {
        currentPage = "usage-breaker"; base("Usage Breaker")
        val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        body.addView(text("Select apps and a daily foreground-time threshold. When you open a selected app after crossing the threshold, the launcher shows a gentle reminder. Usage Access is required.", 12f, muted))
        if (!hasUsageAccess()) button(body, "Grant Usage Access") { try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) {} }
        val threshold = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(prefs.getInt("usageBreakerMinutes", 45).toString()); hint = "Daily limit in minutes"; setTextColor(Color.WHITE) }
        body.addView(text("Daily limit (minutes per selected app)", 13f, muted)); body.addView(threshold)
        val selected = (prefs.getStringSet("usageBreakerApps", emptySet()) ?: emptySet()).toMutableSet()
        apps.forEach { app ->
            val cb = CheckBox(this).apply { text = app.label; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(purple); isChecked = selected.contains(app.packageName) }
            cb.setOnCheckedChangeListener { _, checked -> if (checked) selected.add(app.packageName) else selected.remove(app.packageName) }
            body.addView(cb)
        }
        button(body, "Save Usage Breaker") {
            val minutes = threshold.text.toString().toIntOrNull()?.coerceIn(5, 600) ?: 45
            prefs.edit().putInt("usageBreakerMinutes", minutes).putStringSet("usageBreakerApps", selected).putBoolean("usageBreaker", true).apply()
            Toast.makeText(this, "Usage Breaker saved", Toast.LENGTH_SHORT).show(); showProductivity()
        }
        button(body, "Turn off Usage Breaker") { prefs.edit().putBoolean("usageBreaker", false).apply(); showProductivity() }
    }

    private fun maybeShowUsageBreaker(app: LaunchApp): Boolean {
        if (!prefs.getBoolean("usageBreaker", false)) return false
        val selected = prefs.getStringSet("usageBreakerApps", emptySet()) ?: emptySet()
        if (!selected.contains(app.packageName) || !hasUsageAccess()) return false
        val now = System.currentTimeMillis(); val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val used = try { (getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager).queryAndAggregateUsageStats(cal.timeInMillis, now)[app.packageName]?.totalTimeInForeground ?: 0L } catch (_: Exception) { 0L }
        val limit = prefs.getInt("usageBreakerMinutes", 45) * 60_000L
        val dayKey = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val warnedKey = "usageBreakerWarned:$dayKey:${app.packageName}"
        if (used < limit || prefs.getBoolean(warnedKey, false)) return false
        prefs.edit().putBoolean(warnedKey, true).apply()
        AlertDialog.Builder(this).setTitle("Usage Breaker")
            .setMessage("You've used ${app.label} for ${formatDuration(used)} today, past your ${prefs.getInt("usageBreakerMinutes", 45)} minute limit. Take a short break?")
            .setNegativeButton("Open anyway") { _, _ -> launchApp(app) }
            .setPositiveButton("Take a break", null).show()
        return true
    }

    private fun showClockStyles() { currentPage = "clock-styles"; base("Clock style"); val body = column(14); root.addView(ScrollView(this).apply { addView(body) }); listOf("Minimal digital", "Large digital", "Compact digital", "Time and date", "Stacked clock", "Bold clock", "Classic clock", "No clock").forEachIndexed { i, name -> settingCard(body, name, if (i == prefs.getInt("clockStyle", 0)) "Selected" else "Tap to preview and select") { prefs.edit().putInt("clockStyle", i).apply(); Toast.makeText(this, "$name selected", Toast.LENGTH_SHORT).show(); showClockStyles() } } }
    private fun showIconStyles() {
        currentPage = "icons"; base("App icons"); val body = column(14); root.addView(ScrollView(this).apply { addView(body) })
        listOf("Material", "Stellar", "Dots", "Outline", "Wrapped", "Marble", "Bright", "Muted", "Outline Chroma").forEachIndexed { i, name ->
            val r = row().apply { background = shape(panel, 14); setPadding(dp(14), dp(12), dp(12), dp(12)) }
            val t = text(name, 14f, Color.WHITE); r.addView(t, LinearLayout.LayoutParams(0, dp(34), 1f))
            val radio = RadioButton(this).apply { buttonTintList = android.content.res.ColorStateList.valueOf(purple); isChecked = prefs.getInt("iconStyle", 0) == i; setOnClickListener { prefs.edit().putInt("iconStyle", i).apply(); showIconStyles() } }
            r.addView(radio); r.setOnClickListener { prefs.edit().putInt("iconStyle", i).apply(); showIconStyles() }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(7); body.addView(r, lp)
        }
        settingCard(body, "Edit icons individually", "Choose a gallery image, rename an app, or restore its original icon") { showIndividualIconManager() }
        settingCard(body, "Icon Assistant", "Set a custom image or reset an app icon") { showIndividualIconManager() }
        settingCard(body, "Installed icon packs", "Find icon packs installed on this device") { showInstalledIconPacks() }
    }
    private fun showInstalledIconPacks() {
        currentPage = "icon-packs"; base("Installed icon packs"); val body = column(12); root.addView(ScrollView(this).apply { addView(body) })
        val actions = listOf("com.novalauncher.THEME", "org.adw.launcher.THEMES", "com.anddoes.launcher.THEME")
        val found = linkedMapOf<String, String>()
        actions.forEach { action ->
            try { packageManager.queryIntentActivities(Intent(action), PackageManager.MATCH_ALL).forEach { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@forEach
                if (pkg != packageName) found[pkg] = ri.loadLabel(packageManager)?.toString() ?: pkg
            } } catch (_: Exception) {}
        }
        if (found.isEmpty()) body.addView(text("No compatible icon-pack apps were discovered. Install an icon pack and reopen this screen. You can still customize icons individually.", 13f, muted))
        found.forEach { (pkg, label) -> settingCard(body, label, if (prefs.getString("selectedIconPack", null) == pkg) "Currently applied · tap for options" else "Tap to apply or open this pack") {
            AlertDialog.Builder(this).setTitle(label).setItems(arrayOf("Apply icon pack", "Open icon pack app", "Clear selected pack")) { _, which ->
                when (which) {
                    0 -> { prefs.edit().putString("selectedIconPack", pkg).apply(); showHome() }
                    1 -> try { startActivity(packageManager.getLaunchIntentForPackage(pkg) ?: Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) } catch (_: Exception) { info("Icon pack", "Could not open this icon pack.") }
                    2 -> { prefs.edit().remove("selectedIconPack").apply(); showInstalledIconPacks() }
                }
            }.show()
        } }
        settingCard(body, "Edit icons individually", "Apply custom images to specific apps") { showIndividualIconManager() }
    }

    private fun iconFromSelectedPack(app: LaunchApp): android.graphics.drawable.Drawable? {
        val pack = prefs.getString("selectedIconPack", null) ?: return null
        return try {
            val packResources = packageManager.getResourcesForApplication(pack)
            val xmlId = packResources.getIdentifier("appfilter", "xml", pack)
            if (xmlId == 0) return null
            val parser = packResources.getXml(xmlId)
            var drawableName: String? = null
            var event = parser.eventType
            while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && drawableName == null) {
                if (event == org.xmlpull.v1.XmlPullParser.START_TAG && parser.name == "item") {
                    val component = parser.getAttributeValue(null, "component") ?: ""
                    val drawable = parser.getAttributeValue(null, "drawable")
                    if (component.contains("ComponentInfo{${app.packageName}/") && !drawable.isNullOrBlank()) drawableName = drawable
                }
                event = parser.next()
            }
            parser.close()
            val id = drawableName?.let { packResources.getIdentifier(it, "drawable", pack) } ?: 0
            if (id == 0) null else if (android.os.Build.VERSION.SDK_INT >= 21) packResources.getDrawable(id, null) else @Suppress("DEPRECATION") packResources.getDrawable(id)
        } catch (_: Exception) { null }
    }
    private fun showIndividualIconManager() {
        currentPage = "individual-icons"; base("Edit app icons"); val body = column(10); root.addView(ScrollView(this).apply { addView(body) })
        body.addView(text("Choose any installed app to set a custom image and optional label. Images remain available through Android's persisted document permission.", 12f, muted))
        apps.sortedBy { prefs.getString("name:${it.packageName}", it.label)?.lowercase(Locale.getDefault()) ?: it.label.lowercase(Locale.getDefault()) }.forEach { app ->
            val custom = !prefs.getString("icon:${app.packageName}", null).isNullOrBlank()
            settingCard(body, prefs.getString("name:${app.packageName}", app.label) ?: app.label, if (custom) "Custom icon applied · Tap to edit" else "Original icon · Tap to customize") { showEditApp(app) }
        }
    }
    private fun showSavedThemes() {
        currentPage = "saved-themes"; base("My Themes"); val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        val names = prefs.getStringSet("savedThemeNames", emptySet()) ?: emptySet()
        if (names.isEmpty()) body.addView(text("No saved themes yet. Save your current appearance to create a reusable preset.", 13f, muted))
        names.sorted().forEach { name ->
            settingCard(body, name, "Tap to apply this saved theme") { applySavedTheme(name) }
            settingCard(body, "Delete $name", "Remove this saved preset") { AlertDialog.Builder(this).setTitle("Delete $name?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> val next=(prefs.getStringSet("savedThemeNames", emptySet()) ?: emptySet()).toMutableSet(); next.remove(name); prefs.edit().putStringSet("savedThemeNames", next).remove("theme:$name").apply(); showSavedThemes() }.show() }
        }
        settingCard(body, "Save current theme…", "Save accent, clock, icons and global options") { saveCurrentTheme() }
        settingCard(body, "Create a new theme", "Customize colors, clock and icons") { showThemeEditor() }
    }
    private fun showScreenTimeDashboard(app: LaunchApp?) {
        currentPage = "screen-time"; base(if (app == null) "Screen time" else "Screen time · ${app.label}")
        val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        if (!hasUsageAccess()) {
            body.addView(text("Android requires Usage Access permission to show app activity. Enable it for Niagara Replica, then return here.", 13f, muted))
            button(body, "Grant Usage Access") { try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) {} }
            return
        }
        val manager = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis(); val day = 24L * 60 * 60 * 1000
        val ranges = listOf("Today" to (now - day), "Last 7 days" to (now - 7 * day), "Last 30 days" to (now - 30 * day))
        ranges.forEach { (label, start) ->
            val stats = try { manager.queryAndAggregateUsageStats(start, now) } catch (_: Exception) { emptyMap() }
            val relevant = if (app != null) stats.filterKeys { it == app.packageName } else stats
            val total = relevant.values.sumOf { it.totalTimeInForeground.coerceAtLeast(0L) }
            settingCard(body, label, "Foreground time: ${formatDuration(total)}") {}
            val sorted = relevant.entries.sortedByDescending { it.value.totalTimeInForeground }.take(if (app == null) 8 else 1)
            sorted.forEach { entry ->
                val target = apps.firstOrNull { it.packageName == entry.key }
                if (target != null) body.addView(text("${target.label}   ${formatDuration(entry.value.totalTimeInForeground)}", 12f, muted).apply { setPadding(dp(8), dp(3), 0, dp(3)) })
            }
        }
        button(body, "Refresh usage") { showScreenTimeDashboard(app) }
    }
    private fun formatDuration(ms: Long): String {
        val mins = ms / 60000L; val hours = mins / 60; val rem = mins % 60
        return if (hours > 0) "${hours}h ${rem}m" else "${rem}m"
    }
    private fun showAddToFolder(app: LaunchApp) {
        val names = (prefs.getStringSet("folderNames", emptySet()) ?: emptySet()).toMutableSet()
        val choices = (names.toList() + "Create new folder…").toTypedArray()
        AlertDialog.Builder(this).setTitle("Add ${app.label} to folder").setItems(choices) { _, which ->
            if (which == choices.lastIndex) createFolder(app) else {
                val name = choices[which]; val members = (prefs.getStringSet("folder:$name", emptySet()) ?: emptySet()).toMutableSet(); members.add(app.packageName); names.add(name)
                prefs.edit().putStringSet("folderNames", names).putStringSet("folder:$name", members).apply(); showHome()
            }
        }.setNeutralButton("Manage folders") { _, _ -> showFolderManager() }.show()
    }
    private fun createFolder(app: LaunchApp? = null) {
        val input = EditText(this).apply { hint = "Folder name" }
        AlertDialog.Builder(this).setTitle("Create folder").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
            val name = input.text.toString().trim().take(32); if (name.isBlank()) { info("Folder", "Enter a folder name."); return@setPositiveButton }
            val names = (prefs.getStringSet("folderNames", emptySet()) ?: emptySet()).toMutableSet(); names.add(name)
            val members = (prefs.getStringSet("folder:$name", emptySet()) ?: emptySet()).toMutableSet(); app?.let { members.add(it.packageName) }
            prefs.edit().putStringSet("folderNames", names).putStringSet("folder:$name", members).apply(); showFolderManager()
        }.show()
    }
    private fun showFolderPopup(name: String, members: List<LaunchApp>) {
        val items = members.map { it.label }.toTypedArray()
        AlertDialog.Builder(this).setTitle(name).setItems(items) { _, which -> launchApp(members[which]) }
            .setNeutralButton("Manage") { _, _ -> showFolderManager() }.show()
    }
    private fun renameFolder(old: String) {
        val input = EditText(this).apply { setText(old); selectAll() }
        AlertDialog.Builder(this).setTitle("Rename folder").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val name=input.text.toString().trim().take(32); if (name.isBlank() || name == old) return@setPositiveButton
            val names=(prefs.getStringSet("folderNames", emptySet()) ?: emptySet()).toMutableSet(); val members=prefs.getStringSet("folder:$old", emptySet()) ?: emptySet(); names.remove(old); names.add(name)
            prefs.edit().putStringSet("folderNames", names).putStringSet("folder:$name", members).remove("folder:$old").apply(); showFolderManager()
        }.show()
    }
    private fun deleteFolder(name: String) {
        val names=(prefs.getStringSet("folderNames", emptySet()) ?: emptySet()).toMutableSet(); names.remove(name)
        prefs.edit().putStringSet("folderNames", names).remove("folder:$name").apply(); showHome()
    }
    private fun showFolderManager() {
        currentPage="folders"; base("Folders & Pop-ups"); val body=column(14); root.addView(ScrollView(this).apply { addView(body) })
        val names=prefs.getStringSet("folderNames", emptySet()) ?: emptySet()
        if (names.isEmpty()) body.addView(text("Create folders, then use an app's long-press menu → Add to folder.", 13f, muted))
        names.sorted().forEach { name -> val members=prefs.getStringSet("folder:$name", emptySet()) ?: emptySet(); settingCard(body, name, "${members.size} apps · tap to edit members") { editFolderMembers(name) } }
        button(body, "Create folder") { createFolder() }
    }
    private fun editFolderMembers(name: String) {
        val members=(prefs.getStringSet("folder:$name", emptySet()) ?: emptySet()).toMutableSet()
        val labels=apps.map { it.label }.toTypedArray(); val selected=BooleanArray(apps.size) { members.contains(apps[it].packageName) }
        AlertDialog.Builder(this).setTitle("Apps in $name").setMultiChoiceItems(labels, selected) { _, which, checked -> if (checked) members.add(apps[which].packageName) else members.remove(apps[which].packageName) }
            .setPositiveButton("Save") { _, _ -> prefs.edit().putStringSet("folder:$name", members).apply(); showFolderManager() }
            .setNeutralButton("Rename") { _, _ -> renameFolder(name) }.setNegativeButton("Cancel", null).show()
    }
    private fun saveCurrentTheme() {
        val input=EditText(this).apply { hint="Theme name" }
        AlertDialog.Builder(this).setTitle("Save current theme").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val name=input.text.toString().trim().take(32); if (name.isBlank()) return@setPositiveButton
            val all=prefs.all; val snapshot=JSONObject(); all.forEach { (key,value) -> if (key in setOf("accent","clockStyle","24hour","hideStatus","hideNavigation","hideLabels","showAlphabet","showFavorites","darkTheme","iconStyle","wallpaperUri")) { when(value) { is Boolean -> snapshot.put(key,value); is Int -> snapshot.put(key,value); is String -> snapshot.put(key,value) } } }
            val names=(prefs.getStringSet("savedThemeNames", emptySet()) ?: emptySet()).toMutableSet(); names.add(name)
            prefs.edit().putStringSet("savedThemeNames",names).putString("theme:$name",snapshot.toString()).apply(); showSavedThemes()
        }.show()
    }
    private fun applySavedTheme(name: String) {
        try { val json=JSONObject(prefs.getString("theme:$name", "{}") ?: "{}"); val e=prefs.edit(); json.keys().forEach { key -> when(val v=json.get(key)) { is Boolean -> e.putBoolean(key,v); is Int -> e.putInt(key,v); is String -> e.putString(key,v) } }; e.apply(); applyWindowPreferences(); showHome() }
        catch (_: Exception) { info("Theme", "This saved theme could not be applied.") }
    }
    private fun showAdvanced() { currentPage = "advanced"; base("Advanced"); val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        settingCard(body, "App info", "Launcher version and Android application info") { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {} }
        settingCard(body, "Backup & Restore (Beta)", "Export or restore local launcher preferences") { backupRestore() }
        settingCard(body, "Changelog", "What's new in this version") { info("Changelog", "Version 1.2.0\n• Custom launcher font families and theme typography\n• Widget stacks with up to four hosted widgets\n• Per-app Usage Breaker thresholds and reminders\n• Double-tap alphabet screen-off gesture (Accessibility required)\n• Expanded Pro-style feature hub\n• Existing themes, icons, weather, calendar, media and recording integrations\n\nThis is an independent launcher; official Niagara subscriptions and services are not included.") }
        settingCard(body, "Change default launcher", "Choose this app as your Home app") { try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (_: Exception) { info("Default launcher", "Open Android Settings → Apps → Default apps → Home app.") } }
        settingCard(body, "Uninstall launcher", "Open Android app settings") { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {} }
        settingCard(body, "System settings", "Open Android settings") { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        settingCard(body, "Screen recording", "Recording preparation and system-capture requirements") { startScreenRecordingFlow() }
        settingCard(body, "Reset launcher", "Clear customizations and favorites") { AlertDialog.Builder(this).setTitle("Reset launcher?").setMessage("This clears saved preferences and hidden apps.").setNegativeButton("Cancel", null).setPositiveButton("Reset") { _, _ -> prefs.edit().clear().apply(); showHome() }.show() }
    }
    private fun backupRestore() {
        val opts = arrayOf("Export settings to a backup file", "Import settings from a backup file")
        AlertDialog.Builder(this).setTitle("Backup & Restore").setItems(opts) { _, which ->
            if (which == 0) {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "niagara-replica-settings.json") }
                try { startActivityForResult(intent, requestExport) } catch (_: Exception) { info("Backup", "Could not open the file picker.") }
            } else {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                try { startActivityForResult(intent, requestImport) } catch (_: Exception) { info("Restore", "Could not open the file picker.") }
            }
        }.show()
    }
    private fun exportSettings(uri: Uri) {
        try {
            val json = JSONObject()
            prefs.all.forEach { (key, value) ->
                when (value) {
                    is Set<*> -> json.put(key, JSONObject().put("type", "stringSet").put("value", JSONArray(value.map { it.toString() })))
                    is Boolean -> json.put(key, JSONObject().put("type", "boolean").put("value", value))
                    is Int -> json.put(key, JSONObject().put("type", "int").put("value", value))
                    is Long -> json.put(key, JSONObject().put("type", "long").put("value", value))
                    is Float -> json.put(key, JSONObject().put("type", "float").put("value", value.toDouble()))
                    is String -> json.put(key, JSONObject().put("type", "string").put("value", value))
                }
            }
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json.toString(2)) }
            Toast.makeText(this, "Backup exported", Toast.LENGTH_LONG).show()
        } catch (_: Exception) { info("Backup failed", "The settings backup could not be written to that location.") }
    }
    private fun importSettings(uri: Uri) {
        try {
            val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: throw IllegalStateException("Empty file")
            val json = JSONObject(content)
            val editor = prefs.edit()
            json.keys().forEach { key ->
                val item = json.optJSONObject(key) ?: return@forEach
                val value = item.opt("value")
                when (item.optString("type")) {
                    "stringSet" -> { val arr = item.optJSONArray("value") ?: JSONArray(); val set = mutableSetOf<String>(); for (i in 0 until arr.length()) set.add(arr.optString(i)); editor.putStringSet(key, set) }
                    "boolean" -> editor.putBoolean(key, value as? Boolean ?: false)
                    "int" -> editor.putInt(key, (value as? Number)?.toInt() ?: 0)
                    "long" -> editor.putLong(key, (value as? Number)?.toLong() ?: 0L)
                    "float" -> editor.putFloat(key, (value as? Number)?.toFloat() ?: 0f)
                    "string" -> editor.putString(key, value as? String ?: "")
                }
            }
            editor.apply(); applyWindowPreferences(); showHome(); Toast.makeText(this, "Backup restored", Toast.LENGTH_LONG).show()
        } catch (_: Exception) { info("Restore failed", "This file is not a valid launcher backup. No settings were changed.") }
    }
    private fun showHiddenApps() { currentPage = "hidden"; base("Hidden apps"); val body = column(12); root.addView(body); val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet(); if (hidden.isEmpty()) body.addView(text("No hidden apps", 14f, muted)); apps.filter { hidden.contains(it.packageName) }.forEach { app -> settingCard(body, app.label, "Tap to show again") { val set = hidden.toMutableSet(); set.remove(app.packageName); prefs.edit().putStringSet("hidden", set).apply(); loadApps(); showHiddenApps() } } }
    private fun showWidgetHelp() { addAndroidWidget(null) }
    private fun addAndroidWidget(preferredPackage: String?) {
        try {
            val id = widgetHost.allocateAppWidgetId()
            val provider = if (preferredPackage != null) widgetManager.installedProviders.firstOrNull { it.provider.packageName == preferredPackage } else null
            if (provider != null) {
                if (widgetManager.bindAppWidgetIdIfAllowed(id, provider.provider)) { saveWidgetId(id); return }
                val bind = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider.provider)
                startActivityForResult(bind, requestWidgetBind)
            } else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id), requestWidgetPick)
        } catch (_: Exception) { info("Android widgets", "The system widget picker could not be opened on this device.") }
    }
    private fun saveWidgetId(id: Int) {
        val ids = (prefs.getStringSet("hostedWidgetIds", emptySet()) ?: emptySet()).toMutableSet()
        ids.add(id.toString())
        val order = (prefs.getString("widgetOrder", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
        if (!order.contains(id.toString())) order.add(id.toString())
        val providerPackage = widgetManager.getAppWidgetInfo(id)?.provider?.packageName
        val history = (prefs.getString("widgetHistoryPackages", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
        if (!providerPackage.isNullOrBlank()) { history.remove(providerPackage); history.add(0, providerPackage) }
        prefs.edit().putStringSet("hostedWidgetIds", ids).putString("widgetOrder", order.joinToString(",")).putString("widgetHistoryPackages", history.take(20).joinToString(",")).apply()
        showHome()
    }
    private fun showWidgetStackManager() {
        currentPage = "widget-stacks"; base("Widget stacks")
        val body = column(16); root.addView(ScrollView(this).apply { addView(body) })
        val ids = (prefs.getStringSet("hostedWidgetIds", emptySet()) ?: emptySet()).toList()
        if (ids.size < 2) body.addView(text("Add at least two Android widgets first. A stack can contain up to four widgets.", 13f, muted))
        else {
            body.addView(text("Choose widgets for Stack 1. Widgets not selected remain separate. Android providers may impose their own size limits.", 12f, muted))
            val chosen = ids.filter { prefs.getString("widgetStack:$it", "") == "1" }.toMutableSet()
            ids.forEach { raw ->
                val id = raw.toIntOrNull() ?: return@forEach
                val label = try { widgetManager.getAppWidgetInfo(id)?.loadLabel(packageManager)?.toString() ?: "Widget $id" } catch (_: Exception) { "Widget $id" }
                val cb = CheckBox(this).apply { text = label; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(purple); isChecked = chosen.contains(raw) }
                cb.setOnCheckedChangeListener { _, checked -> if (checked) { if (chosen.size < 4) chosen.add(raw) else { cb.isChecked = false; Toast.makeText(this@MainActivity, "A stack supports up to four widgets", Toast.LENGTH_SHORT).show() } } else chosen.remove(raw) }
                body.addView(cb)
            }
            button(body, "Save Stack 1") {
                val e = prefs.edit(); ids.forEach { e.remove("widgetStack:$it") }; chosen.forEach { e.putString("widgetStack:$it", "1") }; e.apply(); showHome()
            }
            button(body, "Clear Stack") { val e = prefs.edit(); ids.forEach { e.remove("widgetStack:$it") }; e.apply(); showHome() }
        }
    }

    private fun addHostedWidgets(parent: LinearLayout) {
        val ids = (prefs.getStringSet("hostedWidgetIds", emptySet()) ?: emptySet()).toMutableList()
        val order = prefs.getString("widgetOrder", "")?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
        ids.sortBy { raw -> val idx = order.indexOf(raw); if (idx < 0) Int.MAX_VALUE else idx }
        val stackIds = ids.filter { prefs.getString("widgetStack:$it", "") == "1" }
        ids.forEachIndexed { index, raw ->
            if (prefs.getString("widgetStack:$raw", "") == "1" && raw != stackIds.firstOrNull()) return@forEachIndexed
            val renderRaw = if (prefs.getString("widgetStack:$raw", "") == "1") {
                val active = prefs.getString("activeWidgetStack:1", null)
                if (active != null && stackIds.contains(active)) active else raw
            } else raw
            val id = renderRaw.toIntOrNull() ?: return@forEachIndexed
            try {
                val info = widgetManager.getAppWidgetInfo(id) ?: return@forEachIndexed
                val view = widgetHost.createView(this, id, info)
                val scale = prefs.getInt("widgetScale:$id", 1).coerceIn(0, 2)
                val heightDp = when (scale) { 0 -> 110; 2 -> 300; else -> 190 }
                view.setPadding(dp(4), dp(4), dp(4), dp(4))
                view.layoutParams = LinearLayout.LayoutParams(-1, dp(heightDp))
                try { view.updateAppWidgetSize(null, dp(280), dp(heightDp), dp(420), dp(heightDp)) } catch (_: Exception) {}
                val wrap = column(8).apply { background = shape(panel, 16) }
                val header = row().apply { setPadding(dp(8), dp(2), dp(4), dp(2)) }
                if (prefs.getString("widgetStack:$raw", "") == "1" && stackIds.size > 1) {
                    val stackSpinner = Spinner(this)
                    val stackLabels = stackIds.map { stackRaw -> try { val wi = widgetManager.getAppWidgetInfo(stackRaw.toInt()); wi?.loadLabel(packageManager)?.toString() ?: "Widget" } catch (_: Exception) { "Widget" } }
                    stackSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, stackLabels)
                    val selectedIndex = stackIds.indexOf(renderRaw).coerceAtLeast(0); stackSpinner.setSelection(selectedIndex)
                    stackSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, itemId: Long) {
                            val next = stackIds.getOrNull(position) ?: return
                            if (prefs.getString("activeWidgetStack:1", null) != next) { prefs.edit().putString("activeWidgetStack:1", next).apply(); showHome() }
                        }
                    }
                    header.addView(stackSpinner, LinearLayout.LayoutParams(0, dp(36), 1f))
                } else header.addView(text(info.loadLabel(packageManager).toString(), 11f, muted), LinearLayout.LayoutParams(0, dp(28), 1f))
                val options = text("⋮", 22f, purple, true).apply { gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0) }
                header.addView(options, LinearLayout.LayoutParams(dp(38), dp(28)))
                options.setOnClickListener { showWidgetActions(renderRaw, id, index, ids) }
                wrap.addView(header); wrap.addView(view, LinearLayout.LayoutParams(-1, dp(heightDp)))
                wrap.setOnLongClickListener { showWidgetActions(renderRaw, id, index, ids); true }
                val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(12), dp(4), dp(12), dp(8)); parent.addView(wrap, lp)
            } catch (_: Exception) {}
        }
    }
    private fun showWidgetActions(raw: String, id: Int, index: Int, ids: List<String>) {
        val choices = mutableListOf<String>()
        choices.add("Make smaller"); choices.add("Default size"); choices.add("Make larger")
        if (index > 0) choices.add("Move up")
        if (index < ids.lastIndex) choices.add("Move down")
        choices.add("Configure widget"); choices.add("Remove widget")
        AlertDialog.Builder(this).setTitle("Widget options").setItems(choices.toTypedArray()) { _, which ->
            when (val choice = choices[which]) {
                "Make smaller" -> setWidgetScale(id, 0)
                "Default size" -> setWidgetScale(id, 1)
                "Make larger" -> setWidgetScale(id, 2)
                "Move up", "Move down" -> {
                    val next = ids.toMutableList(); val from = next.indexOf(raw); val to = if (choice == "Move up") from - 1 else from + 1
                    if (from >= 0 && to in next.indices) { java.util.Collections.swap(next, from, to); prefs.edit().putString("widgetOrder", next.joinToString(",")).apply(); showHome() }
                }
                "Configure widget" -> try { val widgetInfo = widgetManager.getAppWidgetInfo(id); if (widgetInfo?.configure != null) startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).setComponent(widgetInfo.configure).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id), requestWidgetConfigure) else info("Widget", "This widget has no additional configuration screen.") } catch (_: Exception) { info("Widget", "Could not open widget configuration.") }
                "Remove widget" -> { val next = (prefs.getStringSet("hostedWidgetIds", emptySet()) ?: emptySet()).toMutableSet(); next.remove(raw); prefs.edit().putStringSet("hostedWidgetIds", next).apply(); widgetHost.deleteAppWidgetId(id); showHome() }
            }
        }.show()
    }
    private fun setWidgetScale(id: Int, scale: Int) { prefs.edit().putInt("widgetScale:$id", scale).apply(); showHome() }
    private fun showQuickLook(app: LaunchApp) {
        val usage = if (hasUsageAccess()) try {
            val now = System.currentTimeMillis()
            (getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager).queryAndAggregateUsageStats(now - 7L * 24 * 60 * 60 * 1000, now)[app.packageName]
        } catch (_: Exception) { null } else null
        val installed = try { packageManager.getPackageInfo(app.packageName, 0).firstInstallTime } catch (_: Exception) { 0L }
        val lastUpdate = try { packageManager.getPackageInfo(app.packageName, 0).lastUpdateTime } catch (_: Exception) { 0L }
        val details = buildString {
            append("Package: ${app.packageName}\n")
            append("Installed: ${if (installed > 0) SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(installed)) else "Unknown"}\n")
            append("Updated: ${if (lastUpdate > 0) SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(lastUpdate)) else "Unknown"}\n")
            append("Usage in last 7 days: ${if (usage != null) formatDuration(usage.totalTimeInForeground) else "Allow Usage Access to view"}")
        }
        AlertDialog.Builder(this).setTitle(prefs.getString("name:${app.packageName}", app.label) ?: app.label).setMessage(details)
            .setPositiveButton("Open") { _, _ -> launchApp(app) }
            .setNeutralButton("App info") { _, _ -> openAppInfo(app) }
            .setNegativeButton("Close", null).show()
    }

    private fun showUnusedApps() {
        currentPage = "unused-apps"; base("Unused apps")
        val body = column(14); root.addView(ScrollView(this).apply { addView(body) })
        if (!hasUsageAccess()) {
            body.addView(text("Allow Usage Access to identify apps that have not been used recently.", 13f, muted))
            button(body, "Grant Usage Access") { try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) {} }
            return
        }
        val now = System.currentTimeMillis(); val start = now - 30L * 24 * 60 * 60 * 1000
        val usage = try { (getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager).queryAndAggregateUsageStats(start, now) } catch (_: Exception) { emptyMap() }
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val candidates = apps.filter { !hidden.contains(it.packageName) }.sortedBy { usage[it.packageName]?.lastTimeUsed ?: 0L }
        body.addView(text("Apps are ordered from least recently used. Android does not allow this launcher to uninstall or suspend them silently.", 12f, muted))
        if (candidates.isEmpty()) body.addView(text("No apps found.", 13f, muted))
        candidates.forEach { app ->
            val stat = usage[app.packageName]
            val last = stat?.lastTimeUsed ?: 0L
            val label = if (last <= 0L) "No usage recorded in this period" else "Last used ${SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(last))} · 30-day foreground ${formatDuration(stat?.totalTimeInForeground ?: 0L)}"
            settingCard(body, prefs.getString("name:${app.packageName}", app.label) ?: app.label, label) { showQuickLook(app) }
        }
    }

    private fun showWidgetHistory() {
        currentPage = "widget-history"; base("Widget history")
        val body = column(14); root.addView(ScrollView(this).apply { addView(body) })
        val packages = (prefs.getString("widgetHistoryPackages", "") ?: "").split(",").filter { it.isNotBlank() }
        if (packages.isEmpty()) body.addView(text("Widgets you add will appear here.", 13f, muted))
        packages.forEach { pkg ->
            val provider = try { widgetManager.installedProviders.firstOrNull { it.provider.packageName == pkg } } catch (_: Exception) { null }
            if (provider != null) settingCard(body, provider.loadLabel(packageManager).toString(), pkg) {
                val rawIds = (prefs.getStringSet("hostedWidgetIds", emptySet()) ?: emptySet())
                val existing = rawIds.mapNotNull { it.toIntOrNull() }.firstOrNull { id -> widgetManager.getAppWidgetInfo(id)?.provider?.packageName == pkg }
                if (existing != null) {
                    val ordered = (prefs.getString("widgetOrder", "") ?: "").split(",").filter { it.isNotBlank() }
                    showWidgetActions(existing.toString(), existing, ordered.indexOf(existing.toString()), ordered)
                } else addAndroidWidget(pkg)
            }
        }
        button(body, "Add a widget") { addAndroidWidget(null) }
    }

    private fun showHandyMadeThemes() {
        currentPage = "handy-themes"; base("Handy-Made Themes")
        val body = column(14); root.addView(ScrollView(this).apply { addView(body) })
        val themes = listOf(
            Triple("Violet Night", 0xffa58bff.toInt(), 0),
            Triple("Ocean Glass", 0xff55b5df.toInt(), 2),
            Triple("Rose Quartz", 0xffbd65cf.toInt(), 5),
            Triple("Sage Minimal", 0xff55bd80.toInt(), 6),
            Triple("Amber Focus", 0xffee9b41.toInt(), 1),
            Triple("Mono Light", 0xff526ee2.toInt(), 3)
        )
        body.addView(text("Choose a ready-made local preset. You can fine-tune it afterwards in the theme editor.", 12f, muted))
        themes.forEach { (name, accent, clock) ->
            val card = column(14).apply { background = shape(panel, 16); setOnClickListener {
                prefs.edit().putInt("accent", accent).putInt("clockStyle", clock).putBoolean("darkTheme", name != "Mono Light").apply()
                Toast.makeText(this@MainActivity, "$name applied", Toast.LENGTH_SHORT).show(); showHome()
            } }
            card.addView(text(name, 16f, if (prefs.getBoolean("darkTheme", true)) Color.WHITE else Color.DKGRAY, true))
            card.addView(text("Accent palette · ${if (name == "Mono Light") "light" else "dark"} appearance · clock style ${clock + 1}", 12f, muted))
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8); body.addView(card, lp)
        }
        settingCard(body, "Customize this theme", "Open the full theme editor") { showThemeEditor() }
    }

    private fun startScreenRecordingFlow() {
        val projection = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        AlertDialog.Builder(this).setTitle("Preparing to record…")
            .setMessage("Android will ask you to approve screen capture. The recording notification stays visible while recording. Stop recording from that notification; the video is saved to this app's Movies folder.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ -> try { startActivityForResult(projection.createScreenCaptureIntent(), requestRecordingCapture) } catch (_: Exception) { info("Screen recording", "Screen capture is not available on this device.") } }
            .show()
    }

    private fun showCommunityThemes() {
        currentPage = "community-themes"; base("Community Themes"); val sc = ScrollView(this); val body = column(14); sc.addView(body); root.addView(sc)
        body.addView(text("Browse public GitHub projects tagged for launcher themes. Online results require internet access.", 12f, muted))
        val status = text("Loading community results…", 13f, muted); body.addView(status)
        Thread {
            try {
                val conn = URL("https://api.github.com/search/repositories?q=android+launcher+themes+wallpaper&sort=updated&per_page=20").openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.setRequestProperty("Accept", "application/vnd.github+json")
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() }); val items = json.optJSONArray("items") ?: JSONArray()
                runOnUiThread {
                    body.removeView(status)
                    if (items.length() == 0) body.addView(text("No public theme projects were found. Try again later.", 13f, muted))
                    for (i in 0 until items.length()) { val item = items.getJSONObject(i); val name = item.optString("full_name", "Community project"); val desc = item.optString("description", "No description provided"); val url = item.optString("html_url", "https://github.com"); settingCard(body, name, desc) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} } }
                }
                conn.disconnect()
            } catch (_: Exception) { runOnUiThread { status.text = "Couldn't load online results. Check internet and try again."; val retry = text("Open GitHub theme search ↗", 14f, purple, true).apply { setPadding(0, dp(12), 0, dp(12)); setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/search?q=android+launcher+themes&type=repositories"))) } catch (_: Exception) {} } }; body.addView(retry) } }
        }.start()
    }
    private fun openExternal(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { info("Open link", "No browser is available.") } }
    private fun info(title: String, message: String) { AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show() }
    private fun button(parent: LinearLayout, label: String, action: () -> Unit) { val b = Button(this).apply { text = label; setTextColor(Color.WHITE); background = shape(purple, 22); setOnClickListener { action() } }; parent.addView(b, LinearLayout.LayoutParams(-1, dp(48))) }
}
